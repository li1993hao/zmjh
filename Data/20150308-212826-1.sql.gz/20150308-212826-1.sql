-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 3306
-- Database : baibang
-- 
-- Part : #1
-- Date : 2015-03-08 21:28:26
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `jdi_action`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_action`;
CREATE TABLE `jdi_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `jdi_action`
-- -----------------------------
INSERT INTO `jdi_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '[user|get_nickname]在[time|time_format]登录了后台', '1', '1', '1387181220');
INSERT INTO `jdi_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '', '2', '1', '1380173180');
INSERT INTO `jdi_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '0', '1383285646');
INSERT INTO `jdi_action` VALUES ('4', 'add_document', '发表文档', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '[user|get_nickname]在[time|time_format]发表了一篇文章。\r\n表[model]，记录编号[record]。', '2', '1', '1386139726');
INSERT INTO `jdi_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '-1', '1418542406');
INSERT INTO `jdi_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '-1', '1418542415');
INSERT INTO `jdi_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057');
INSERT INTO `jdi_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963');
INSERT INTO `jdi_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '-1', '1418890941');
INSERT INTO `jdi_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392');
INSERT INTO `jdi_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '-1', '1418540966');
INSERT INTO `jdi_action` VALUES ('12', 'update_sports', '更新项目库', '更新项目库', '', '', '1', '1', '1419212751');

-- -----------------------------
-- Table structure for `jdi_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_action_log`;
CREATE TABLE `jdi_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=877 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `jdi_action_log`
-- -----------------------------
INSERT INTO `jdi_action_log` VALUES ('701', '10', '1', '0', 'Menu', '269', '操作url：/jdicms/admin.php/Menu-add.html', '1', '1421198978');
INSERT INTO `jdi_action_log` VALUES ('702', '10', '1', '0', 'Menu', '270', '操作url：/jdicms/admin.php/Menu-add.html', '1', '1421199033');
INSERT INTO `jdi_action_log` VALUES ('703', '10', '1', '0', 'Menu', '271', '操作url：/jdicms/admin.php/Menu-add.html', '1', '1421199059');
INSERT INTO `jdi_action_log` VALUES ('704', '1', '1', '0', 'member', '1', '李浩在2015-01-17 16:38登录了后台', '1', '1421483934');
INSERT INTO `jdi_action_log` VALUES ('705', '1', '1', '0', 'member', '1', '李浩在2015-01-17 16:39登录了后台', '1', '1421483963');
INSERT INTO `jdi_action_log` VALUES ('706', '1', '1', '0', 'member', '1', '李浩在2015-01-22 09:58登录了后台', '1', '1421891910');
INSERT INTO `jdi_action_log` VALUES ('707', '1', '1', '0', 'member', '1', '李浩在2015-01-22 09:58登录了后台', '1', '1421891922');
INSERT INTO `jdi_action_log` VALUES ('708', '10', '1', '0', 'Menu', '272', '操作url：/jdicms/admin.php/Menu-edit.html', '1', '1422062065');
INSERT INTO `jdi_action_log` VALUES ('709', '10', '1', '0', 'Menu', '273', '操作url：/jdicms/admin.php/Menu-edit.html', '1', '1422062073');
INSERT INTO `jdi_action_log` VALUES ('710', '10', '1', '0', 'Menu', '274', '操作url：/jdicms/admin.php/Menu-edit.html', '1', '1422062093');
INSERT INTO `jdi_action_log` VALUES ('711', '10', '1', '0', 'Menu', '275', '操作url：/jdicms/admin.php/Menu-edit.html', '1', '1422062222');
INSERT INTO `jdi_action_log` VALUES ('712', '10', '1', '0', 'Menu', '276', '操作url：/jdicms/admin.php/Menu-edit.html', '1', '1422062233');
INSERT INTO `jdi_action_log` VALUES ('713', '1', '1', '0', 'member', '1', '李浩在2015-01-26 10:03登录了后台', '1', '1422237828');
INSERT INTO `jdi_action_log` VALUES ('714', '1', '1', '0', 'member', '1', '李浩在2015-01-26 10:03登录了后台', '1', '1422237834');
INSERT INTO `jdi_action_log` VALUES ('715', '8', '1', '0', 'attribute', '256', '操作url：/jdicms/admin.php/Attribute-update.html', '1', '1422241670');
INSERT INTO `jdi_action_log` VALUES ('716', '1', '1', '0', 'member', '1', '李浩在2015-01-26 22:40登录了后台', '1', '1422283228');
INSERT INTO `jdi_action_log` VALUES ('717', '10', '1', '0', 'Menu', '277', '操作url：/jdicms/admin.php/Menu-add.html', '1', '1422338074');
INSERT INTO `jdi_action_log` VALUES ('718', '1', '1', '0', 'member', '1', '李浩在2015-01-28 01:41登录了后台', '1', '1422380492');
INSERT INTO `jdi_action_log` VALUES ('719', '1', '1', '0', 'member', '1', '李浩在2015-01-28 01:41登录了后台', '1', '1422380501');
INSERT INTO `jdi_action_log` VALUES ('720', '10', '1', '0', 'Menu', '278', '操作url：/jdicms/admin.php/Menu-add.html', '1', '1422386053');
INSERT INTO `jdi_action_log` VALUES ('721', '10', '1', '0', 'Menu', '278', '操作url：/jdicms/admin.php/Menu-edit.html', '1', '1422413687');
INSERT INTO `jdi_action_log` VALUES ('722', '10', '1', '0', 'Menu', '279', '操作url：/jdicms/admin.php/Menu-add.html', '1', '1422413727');
INSERT INTO `jdi_action_log` VALUES ('723', '1', '1', '0', 'member', '1', '李浩在2015-01-28 12:18登录了后台', '1', '1422418681');
INSERT INTO `jdi_action_log` VALUES ('724', '1', '1', '0', 'member', '1', '李浩在2015-01-28 15:13登录了后台', '1', '1422429234');
INSERT INTO `jdi_action_log` VALUES ('725', '10', '1', '0', 'Menu', '280', '操作url：/jdicms/admin.php/Menu-add.html', '1', '1422431010');
INSERT INTO `jdi_action_log` VALUES ('726', '1', '1', '0', 'member', '1', '李浩在2015-01-28 20:07登录了后台', '1', '1422446832');
INSERT INTO `jdi_action_log` VALUES ('727', '1', '1', '0', 'member', '1', '李浩在2015-01-28 20:22登录了后台', '1', '1422447737');
INSERT INTO `jdi_action_log` VALUES ('728', '1', '36', '0', 'member', '36', 'test在2015-01-29 15:22登录了后台', '1', '1422516174');
INSERT INTO `jdi_action_log` VALUES ('729', '1', '36', '0', 'member', '36', 'test在2015-01-29 15:27登录了后台', '1', '1422516440');
INSERT INTO `jdi_action_log` VALUES ('730', '1', '36', '0', 'member', '36', 'test在2015-01-29 15:30登录了后台', '1', '1422516631');
INSERT INTO `jdi_action_log` VALUES ('731', '1', '1', '0', 'member', '1', '李浩在2015-01-29 15:57登录了后台', '1', '1422518269');
INSERT INTO `jdi_action_log` VALUES ('732', '1', '1', '0', 'member', '1', '李浩在2015-01-29 15:58登录了后台', '1', '1422518299');
INSERT INTO `jdi_action_log` VALUES ('733', '1', '36', '0', 'member', '36', 'test在2015-01-29 15:58登录了后台', '1', '1422518322');
INSERT INTO `jdi_action_log` VALUES ('734', '1', '1', '0', 'member', '1', '李浩在2015-01-29 18:03登录了后台', '1', '1422525797');
INSERT INTO `jdi_action_log` VALUES ('735', '1', '36', '3232235633', 'member', '36', 'test在2015-01-29 19:44登录了后台', '1', '1422531841');
INSERT INTO `jdi_action_log` VALUES ('736', '1', '1', '0', 'member', '1', '李浩在2015-01-30 10:09登录了后台', '1', '1422583771');
INSERT INTO `jdi_action_log` VALUES ('737', '1', '1', '2130706433', 'member', '1', '李浩在2015-01-30 15:43登录了后台', '1', '1422603818');
INSERT INTO `jdi_action_log` VALUES ('738', '1', '1', '2130706433', 'member', '1', '李浩在2015-01-31 12:24登录了后台', '1', '1422678241');
INSERT INTO `jdi_action_log` VALUES ('739', '1', '1', '2130706433', 'member', '1', '李浩在2015-01-31 19:19登录了后台', '1', '1422703195');
INSERT INTO `jdi_action_log` VALUES ('740', '1', '1', '2130706433', 'member', '1', '李浩在2015-02-02 09:39登录了后台', '1', '1422841185');
INSERT INTO `jdi_action_log` VALUES ('741', '1', '1', '2130706433', 'member', '1', '李浩在2015-02-02 10:43登录了后台', '1', '1422845012');
INSERT INTO `jdi_action_log` VALUES ('742', '1', '1', '3232235620', 'member', '1', '李浩在2015-02-02 16:03登录了后台', '1', '1422864235');
INSERT INTO `jdi_action_log` VALUES ('743', '8', '1', '2130706433', 'attribute', '237', '操作url：/jdicms/Attribute/update.html', '1', '1422868639');
INSERT INTO `jdi_action_log` VALUES ('744', '8', '1', '2130706433', 'attribute', '256', '操作url：/jdicms/Attribute/update.html', '1', '1422869436');
INSERT INTO `jdi_action_log` VALUES ('745', '1', '1', '3232235620', 'member', '1', '李浩在2015-02-02 17:32登录了后台', '1', '1422869552');
INSERT INTO `jdi_action_log` VALUES ('746', '1', '1', '3232235620', 'member', '1', '李浩在2015-02-03 14:58登录了后台', '1', '1422946695');
INSERT INTO `jdi_action_log` VALUES ('747', '1', '1', '3232235895', 'member', '1', '李浩在2015-02-04 20:31登录了后台', '1', '1423053075');
INSERT INTO `jdi_action_log` VALUES ('748', '1', '1', '3232235620', 'member', '1', '李浩在2015-02-05 09:38登录了后台', '1', '1423100288');
INSERT INTO `jdi_action_log` VALUES ('749', '1', '1', '3232235620', 'member', '1', '李浩在2015-02-05 19:26登录了后台', '1', '1423135570');
INSERT INTO `jdi_action_log` VALUES ('750', '1', '1', '2130706433', 'member', '1', '李浩在2015-02-06 10:26登录了后台', '1', '1423189595');
INSERT INTO `jdi_action_log` VALUES ('751', '1', '1', '2130706433', 'member', '1', '李浩在2015-02-06 11:08登录了后台', '1', '1423192098');
INSERT INTO `jdi_action_log` VALUES ('752', '1', '1', '2130706433', 'member', '1', '李浩在2015-02-27 19:38登录了后台', '1', '1425037090');
INSERT INTO `jdi_action_log` VALUES ('753', '1', '1', '2130706433', 'member', '1', '李浩在2015-02-28 13:37登录了后台', '1', '1425101836');
INSERT INTO `jdi_action_log` VALUES ('754', '7', '1', '2130706433', 'model', '33', '操作url：/xuegaobang/Model/update.html', '1', '1425109140');
INSERT INTO `jdi_action_log` VALUES ('755', '8', '1', '2130706433', 'attribute', '257', '操作url：/xuegaobang/Attribute/update.html', '1', '1425109188');
INSERT INTO `jdi_action_log` VALUES ('756', '8', '1', '2130706433', 'attribute', '258', '操作url：/xuegaobang/Attribute/update.html', '1', '1425109219');
INSERT INTO `jdi_action_log` VALUES ('757', '8', '1', '2130706433', 'attribute', '259', '操作url：/xuegaobang/Attribute/update.html', '1', '1425109343');
INSERT INTO `jdi_action_log` VALUES ('758', '8', '1', '2130706433', 'attribute', '260', '操作url：/xuegaobang/Attribute/update.html', '1', '1425109424');
INSERT INTO `jdi_action_log` VALUES ('759', '8', '1', '2130706433', 'attribute', '261', '操作url：/xuegaobang/Attribute/update.html', '1', '1425109486');
INSERT INTO `jdi_action_log` VALUES ('760', '8', '1', '2130706433', 'attribute', '262', '操作url：/xuegaobang/Attribute/update.html', '1', '1425109515');
INSERT INTO `jdi_action_log` VALUES ('761', '8', '1', '2130706433', 'attribute', '263', '操作url：/xuegaobang/Attribute/update.html', '1', '1425109593');
INSERT INTO `jdi_action_log` VALUES ('762', '7', '1', '2130706433', 'model', '34', '操作url：/xuegaobang/Model/update.html', '1', '1425109845');
INSERT INTO `jdi_action_log` VALUES ('763', '8', '1', '2130706433', 'attribute', '264', '操作url：/xuegaobang/Attribute/update.html', '1', '1425110016');
INSERT INTO `jdi_action_log` VALUES ('764', '8', '1', '2130706433', 'attribute', '265', '操作url：/xuegaobang/Attribute/update.html', '1', '1425110118');
INSERT INTO `jdi_action_log` VALUES ('765', '8', '1', '2130706433', 'attribute', '267', '操作url：/xuegaobang/Attribute/update.html', '1', '1425110300');
INSERT INTO `jdi_action_log` VALUES ('766', '1', '37', '2130706433', 'member', '37', 'ds在2015-02-28 17:13登录了后台', '1', '1425114822');
INSERT INTO `jdi_action_log` VALUES ('767', '1', '1', '2130706433', 'member', '1', '李浩在2015-02-28 17:15登录了后台', '1', '1425114916');
INSERT INTO `jdi_action_log` VALUES ('768', '1', '38', '2130706433', 'member', '38', '时代科技在2015-02-28 17:20登录了后台', '1', '1425115227');
INSERT INTO `jdi_action_log` VALUES ('769', '1', '1', '2130706433', 'member', '1', '李浩在2015-02-28 17:22登录了后台', '1', '1425115324');
INSERT INTO `jdi_action_log` VALUES ('770', '1', '39', '2130706433', 'member', '39', '时代科技在2015-02-28 17:25登录了后台', '1', '1425115548');
INSERT INTO `jdi_action_log` VALUES ('771', '1', '1', '2130706433', 'member', '1', '李浩在2015-02-28 17:26登录了后台', '1', '1425115563');
INSERT INTO `jdi_action_log` VALUES ('772', '1', '39', '2130706433', 'member', '39', '时代科技在2015-02-28 17:29登录了后台', '1', '1425115789');
INSERT INTO `jdi_action_log` VALUES ('773', '1', '1', '2130706433', 'member', '1', '李浩在2015-02-28 17:47登录了后台', '1', '1425116874');
INSERT INTO `jdi_action_log` VALUES ('774', '8', '1', '2130706433', 'attribute', '268', '操作url：/xuegaobang/Attribute/update.html', '1', '1425116920');
INSERT INTO `jdi_action_log` VALUES ('775', '1', '39', '2130706433', 'member', '39', '时代科技在2015-02-28 17:49登录了后台', '1', '1425116969');
INSERT INTO `jdi_action_log` VALUES ('776', '1', '1', '2130706433', 'member', '1', '李浩在2015-02-28 18:38登录了后台', '1', '1425119882');
INSERT INTO `jdi_action_log` VALUES ('777', '1', '39', '2130706433', 'member', '39', '时代科技在2015-03-01 10:35登录了后台', '1', '1425177324');
INSERT INTO `jdi_action_log` VALUES ('778', '1', '39', '2130706433', 'member', '39', '时代科技在2015-03-01 11:58登录了后台', '1', '1425182317');
INSERT INTO `jdi_action_log` VALUES ('779', '1', '1', '2130706433', 'member', '1', '李浩在2015-03-01 12:03登录了后台', '1', '1425182585');
INSERT INTO `jdi_action_log` VALUES ('780', '8', '1', '2130706433', 'attribute', '269', '操作url：/xuegaobang/Attribute/update.html', '1', '1425182665');
INSERT INTO `jdi_action_log` VALUES ('781', '8', '1', '2130706433', 'attribute', '270', '操作url：/xuegaobang/Attribute/update.html', '1', '1425182677');
INSERT INTO `jdi_action_log` VALUES ('782', '8', '1', '2130706433', 'attribute', '270', '操作url：/xuegaobang/Attribute/update.html', '1', '1425182836');
INSERT INTO `jdi_action_log` VALUES ('783', '1', '1', '2130706433', 'member', '1', '李浩在2015-03-01 13:53登录了后台', '1', '1425189217');
INSERT INTO `jdi_action_log` VALUES ('784', '1', '39', '2130706433', 'member', '39', '时代科技在2015-03-01 13:54登录了后台', '1', '1425189245');
INSERT INTO `jdi_action_log` VALUES ('785', '1', '1', '2130706433', 'member', '1', '李浩在2015-03-01 13:56登录了后台', '1', '1425189387');
INSERT INTO `jdi_action_log` VALUES ('786', '8', '1', '2130706433', 'attribute', '271', '操作url：/xuegaobang/Attribute/update.html', '1', '1425189430');
INSERT INTO `jdi_action_log` VALUES ('787', '1', '39', '2130706433', 'member', '39', '时代科技在2015-03-01 13:57登录了后台', '1', '1425189447');
INSERT INTO `jdi_action_log` VALUES ('788', '1', '1', '2130706433', 'member', '1', '在2015-03-01 16:01登录了后台', '1', '1425196877');
INSERT INTO `jdi_action_log` VALUES ('789', '1', '1', '2130706433', 'member', '1', '在2015-03-01 16:20登录了后台', '1', '1425198045');
INSERT INTO `jdi_action_log` VALUES ('790', '1', '40', '2130706433', 'member', '40', '在2015-03-02 08:41登录了后台', '1', '1425256874');
INSERT INTO `jdi_action_log` VALUES ('791', '1', '1', '2130706433', 'member', '1', '在2015-03-02 08:43登录了后台', '1', '1425256987');
INSERT INTO `jdi_action_log` VALUES ('792', '1', '1', '2130706433', 'member', '1', '在2015-03-02 09:43登录了后台', '1', '1425260594');
INSERT INTO `jdi_action_log` VALUES ('793', '1', '1', '2130706433', 'member', '1', '在2015-03-02 10:08登录了后台', '1', '1425262109');
INSERT INTO `jdi_action_log` VALUES ('794', '7', '1', '2130706433', 'model', '35', '操作url：/xuegaobang/index.php?s=/Model/update.html', '1', '1425296068');
INSERT INTO `jdi_action_log` VALUES ('795', '8', '1', '2130706433', 'attribute', '272', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425296171');
INSERT INTO `jdi_action_log` VALUES ('796', '8', '1', '2130706433', 'attribute', '272', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425296377');
INSERT INTO `jdi_action_log` VALUES ('797', '7', '1', '2130706433', 'model', '35', '操作url：/xuegaobang/index.php?s=/Model/update.html', '1', '1425296617');
INSERT INTO `jdi_action_log` VALUES ('798', '8', '1', '2130706433', 'attribute', '273', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425296950');
INSERT INTO `jdi_action_log` VALUES ('799', '1', '1', '0', 'member', '1', '在2015-03-03 11:09登录了后台', '1', '1425352162');
INSERT INTO `jdi_action_log` VALUES ('800', '8', '1', '0', 'attribute', '274', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425352502');
INSERT INTO `jdi_action_log` VALUES ('801', '8', '1', '0', 'attribute', '274', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425352571');
INSERT INTO `jdi_action_log` VALUES ('802', '7', '1', '0', 'model', '36', '操作url：/xuegaobang/index.php?s=/Model/update.html', '1', '1425352676');
INSERT INTO `jdi_action_log` VALUES ('803', '8', '1', '0', 'attribute', '275', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425352734');
INSERT INTO `jdi_action_log` VALUES ('804', '7', '1', '0', 'model', '36', '操作url：/xuegaobang/index.php?s=/Model/update.html', '1', '1425352903');
INSERT INTO `jdi_action_log` VALUES ('805', '7', '1', '0', 'model', '37', '操作url：/xuegaobang/index.php?s=/Model/update.html', '1', '1425353078');
INSERT INTO `jdi_action_log` VALUES ('806', '8', '1', '0', 'attribute', '276', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425353140');
INSERT INTO `jdi_action_log` VALUES ('807', '8', '1', '0', 'attribute', '277', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425353171');
INSERT INTO `jdi_action_log` VALUES ('808', '8', '1', '0', 'attribute', '274', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425353821');
INSERT INTO `jdi_action_log` VALUES ('809', '8', '1', '0', 'attribute', '274', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425357901');
INSERT INTO `jdi_action_log` VALUES ('810', '8', '1', '0', 'attribute', '277', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425361510');
INSERT INTO `jdi_action_log` VALUES ('811', '8', '1', '0', 'attribute', '278', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425362012');
INSERT INTO `jdi_action_log` VALUES ('812', '8', '1', '0', 'attribute', '278', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425362108');
INSERT INTO `jdi_action_log` VALUES ('813', '7', '1', '0', 'model', '37', '操作url：/xuegaobang/index.php?s=/Model/update.html', '1', '1425362345');
INSERT INTO `jdi_action_log` VALUES ('814', '8', '1', '0', 'attribute', '279', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425362392');
INSERT INTO `jdi_action_log` VALUES ('815', '7', '1', '0', 'model', '37', '操作url：/xuegaobang/index.php?s=/Model/update.html', '1', '1425363640');
INSERT INTO `jdi_action_log` VALUES ('816', '8', '1', '0', 'attribute', '280', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425364208');
INSERT INTO `jdi_action_log` VALUES ('817', '8', '1', '0', 'attribute', '278', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425366334');
INSERT INTO `jdi_action_log` VALUES ('818', '8', '1', '0', 'attribute', '279', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425366370');
INSERT INTO `jdi_action_log` VALUES ('819', '8', '1', '0', 'attribute', '281', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425368005');
INSERT INTO `jdi_action_log` VALUES ('820', '7', '1', '0', 'model', '37', '操作url：/xuegaobang/index.php?s=/Model/update.html', '1', '1425371307');
INSERT INTO `jdi_action_log` VALUES ('821', '1', '1', '0', 'member', '1', 'haomeaassss在2015-03-04 13:23登录了后台', '1', '1425446587');
INSERT INTO `jdi_action_log` VALUES ('822', '1', '1', '0', 'member', '1', 'haomeaassss在2015-03-04 13:47登录了后台', '1', '1425448077');
INSERT INTO `jdi_action_log` VALUES ('823', '1', '1', '2130706433', 'member', '1', 'haomeaassss在2015-03-04 16:22登录了后台', '1', '1425457328');
INSERT INTO `jdi_action_log` VALUES ('824', '8', '1', '2130706433', 'attribute', '276', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425457369');
INSERT INTO `jdi_action_log` VALUES ('825', '8', '1', '2130706433', 'attribute', '277', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425457387');
INSERT INTO `jdi_action_log` VALUES ('826', '8', '1', '2130706433', 'attribute', '277', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425457444');
INSERT INTO `jdi_action_log` VALUES ('827', '8', '1', '2130706433', 'attribute', '277', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425457620');
INSERT INTO `jdi_action_log` VALUES ('828', '8', '1', '2130706433', 'attribute', '277', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425457642');
INSERT INTO `jdi_action_log` VALUES ('829', '8', '1', '2130706433', 'attribute', '277', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425457991');
INSERT INTO `jdi_action_log` VALUES ('830', '1', '1', '0', 'member', '1', 'haomeaassss在2015-03-04 19:15登录了后台', '1', '1425467705');
INSERT INTO `jdi_action_log` VALUES ('831', '8', '1', '0', 'attribute', '282', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425522185');
INSERT INTO `jdi_action_log` VALUES ('832', '8', '1', '0', 'attribute', '283', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425522876');
INSERT INTO `jdi_action_log` VALUES ('833', '1', '1', '0', 'member', '1', 'haomeaassss在2015-03-05 14:07登录了后台', '1', '1425535633');
INSERT INTO `jdi_action_log` VALUES ('834', '8', '1', '0', 'attribute', '259', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425547844');
INSERT INTO `jdi_action_log` VALUES ('835', '8', '1', '0', 'attribute', '259', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425548095');
INSERT INTO `jdi_action_log` VALUES ('836', '1', '1', '0', 'member', '1', 'haomeaassss在2015-03-06 09:19登录了后台', '1', '1425604798');
INSERT INTO `jdi_action_log` VALUES ('837', '8', '1', '0', 'attribute', '284', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425607061');
INSERT INTO `jdi_action_log` VALUES ('838', '8', '1', '0', 'attribute', '285', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425607829');
INSERT INTO `jdi_action_log` VALUES ('839', '8', '1', '0', 'attribute', '259', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425608040');
INSERT INTO `jdi_action_log` VALUES ('840', '7', '1', '0', 'model', '38', '操作url：/xuegaobang/index.php?s=/Model/update.html', '1', '1425609632');
INSERT INTO `jdi_action_log` VALUES ('841', '8', '1', '0', 'attribute', '286', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425609733');
INSERT INTO `jdi_action_log` VALUES ('842', '8', '1', '0', 'attribute', '287', '操作url：/xuegaobang/index.php?s=/Attribute/remove/id/287.html', '1', '1425609925');
INSERT INTO `jdi_action_log` VALUES ('843', '8', '1', '0', 'attribute', '288', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425609955');
INSERT INTO `jdi_action_log` VALUES ('844', '8', '1', '0', 'attribute', '289', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425609991');
INSERT INTO `jdi_action_log` VALUES ('845', '8', '1', '0', 'attribute', '290', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425610059');
INSERT INTO `jdi_action_log` VALUES ('846', '1', '1', '0', 'member', '1', 'haomeaassss在2015-03-06 12:14登录了后台', '1', '1425615291');
INSERT INTO `jdi_action_log` VALUES ('847', '8', '1', '0', 'attribute', '285', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425620963');
INSERT INTO `jdi_action_log` VALUES ('848', '7', '1', '0', 'model', '39', '操作url：/xuegaobang/index.php?s=/Model/update.html', '1', '1425626558');
INSERT INTO `jdi_action_log` VALUES ('849', '8', '1', '0', 'attribute', '280', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425626655');
INSERT INTO `jdi_action_log` VALUES ('850', '8', '1', '0', 'attribute', '291', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425626724');
INSERT INTO `jdi_action_log` VALUES ('851', '8', '1', '0', 'attribute', '262', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425626776');
INSERT INTO `jdi_action_log` VALUES ('852', '8', '1', '0', 'attribute', '292', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425626813');
INSERT INTO `jdi_action_log` VALUES ('853', '8', '1', '0', 'attribute', '264', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425628902');
INSERT INTO `jdi_action_log` VALUES ('854', '8', '1', '0', 'attribute', '259', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425628983');
INSERT INTO `jdi_action_log` VALUES ('855', '8', '1', '0', 'attribute', '263', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425629001');
INSERT INTO `jdi_action_log` VALUES ('856', '8', '1', '0', 'attribute', '293', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425632867');
INSERT INTO `jdi_action_log` VALUES ('857', '8', '1', '0', 'attribute', '294', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425632951');
INSERT INTO `jdi_action_log` VALUES ('858', '1', '1', '0', 'member', '1', 'haomeaassss在2015-03-07 09:16登录了后台', '1', '1425691002');
INSERT INTO `jdi_action_log` VALUES ('859', '1', '1', '3232235627', 'member', '1', 'haomeaassss在2015-03-07 09:24登录了后台', '1', '1425691452');
INSERT INTO `jdi_action_log` VALUES ('860', '1', '1', '0', 'member', '1', 'haomeaassss在2015-03-07 10:15登录了后台', '1', '1425694524');
INSERT INTO `jdi_action_log` VALUES ('861', '8', '1', '0', 'attribute', '292', '操作url：/xuegaobang/index.php?s=/Attribute/remove/id/292.html', '1', '1425695347');
INSERT INTO `jdi_action_log` VALUES ('862', '8', '1', '0', 'attribute', '262', '操作url：/xuegaobang/index.php?s=/Attribute/remove/id/262.html', '1', '1425695370');
INSERT INTO `jdi_action_log` VALUES ('863', '8', '1', '0', 'attribute', '261', '操作url：/xuegaobang/index.php?s=/Attribute/remove/id/261.html', '1', '1425695376');
INSERT INTO `jdi_action_log` VALUES ('864', '8', '1', '0', 'attribute', '291', '操作url：/xuegaobang/index.php?s=/Attribute/remove/id/291.html', '1', '1425695398');
INSERT INTO `jdi_action_log` VALUES ('865', '8', '1', '0', 'attribute', '295', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425696170');
INSERT INTO `jdi_action_log` VALUES ('866', '1', '1', '3232235627', 'member', '1', 'haomeaassss在2015-03-07 10:50登录了后台', '1', '1425696645');
INSERT INTO `jdi_action_log` VALUES ('867', '1', '1', '3232235627', 'member', '1', 'haomeaassss在2015-03-07 12:05登录了后台', '1', '1425701108');
INSERT INTO `jdi_action_log` VALUES ('868', '1', '44', '3232235627', 'member', '44', '文波在2015-03-07 12:10登录了后台', '1', '1425701408');
INSERT INTO `jdi_action_log` VALUES ('869', '1', '1', '0', 'member', '1', 'haomeaassss在2015-03-07 12:11登录了后台', '1', '1425701502');
INSERT INTO `jdi_action_log` VALUES ('870', '8', '1', '0', 'attribute', '296', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425701686');
INSERT INTO `jdi_action_log` VALUES ('871', '8', '1', '0', 'attribute', '297', '操作url：/xuegaobang/index.php?s=/Attribute/update.html', '1', '1425701701');
INSERT INTO `jdi_action_log` VALUES ('872', '1', '1', '0', 'member', '1', 'haomeaassss在2015-03-07 14:32登录了后台', '1', '1425709927');
INSERT INTO `jdi_action_log` VALUES ('873', '1', '1', '3232235627', 'member', '1', 'haomeaassss在2015-03-07 14:36登录了后台', '1', '1425710169');
INSERT INTO `jdi_action_log` VALUES ('874', '1', '44', '3232235627', 'member', '44', '文波在2015-03-07 15:34登录了后台', '1', '1425713690');
INSERT INTO `jdi_action_log` VALUES ('875', '1', '1', '0', 'member', '1', 'haomeaassss在2015-03-07 19:41登录了后台', '1', '1425728468');
INSERT INTO `jdi_action_log` VALUES ('876', '1', '1', '0', 'member', '1', 'haomeaassss在2015-03-08 21:18登录了后台', '1', '1425820716');

-- -----------------------------
-- Table structure for `jdi_addons`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_addons`;
CREATE TABLE `jdi_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `jdi_addons`
-- -----------------------------
INSERT INTO `jdi_addons` VALUES ('4', 'SystemInfo', '系统环境信息', '用于显示一些服务器的信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512036', '0');
INSERT INTO `jdi_addons` VALUES ('25', 'IPlistener', '来访记录', '记录来访者的IP等信息', '1', '{\"iptime\":\"10\"}', 'tp', '0.1', '1422867149', '1');
INSERT INTO `jdi_addons` VALUES ('28', 'ApiDoc', 'api文档生成器', '生成模块api文档', '1', '{\"url\":\"http:\\/\\/localhost\\/xuegaobang\\/api.php\"}', 'tiptimes', '0.1', '1425452129', '1');

-- -----------------------------
-- Table structure for `jdi_article`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_article`;
CREATE TABLE `jdi_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `uid` int(10) unsigned NOT NULL COMMENT '发布用户id',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `link` varchar(255) NOT NULL COMMENT '外链',
  `deadline` int(10) NOT NULL COMMENT '截止时间',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览数量',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '更新时间',
  `url` varchar(255) NOT NULL COMMENT '内容页面url',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  `title_color` char(10) NOT NULL DEFAULT '#555' COMMENT '内容页标题颜色',
  `list_color` char(10) NOT NULL DEFAULT '#555' COMMENT '列表页标题颜色',
  `content` text NOT NULL COMMENT '文章内容',
  `is_up` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `position` varchar(100) NOT NULL DEFAULT '0' COMMENT '推荐位',
  `cover` varchar(150) NOT NULL COMMENT '封面',
  `extend` text NOT NULL COMMENT '扩展统计字段',
  `weight` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '权重',
  `keyword` varchar(255) NOT NULL COMMENT '关键词',
  `auto_image` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '提取封面图片',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `jdi_article`
-- -----------------------------
INSERT INTO `jdi_article` VALUES ('1', '我', '1', '3', '&lt;img src=&quot;/jdicms/Uploads/editor/image/20150123/54c2184529ef0.jpg&quot; title=&quot;54c2184529ef0.jpg&quot; alt=&quot;u=772942726,2163368331&amp;amp;', '', '0', '53', '1422006401', '1422527840', '', '1', '#555', '#555', '&lt;p&gt;&lt;img src=&quot;/jdicms/Uploads/editor/image/20150123/54c2184529ef0.jpg&quot; title=&quot;54c2184529ef0.jpg&quot; alt=&quot;u=772942726,2163368331&amp;amp;fm=21&amp;amp;gp=0.jpg&quot;/&gt;&lt;/p&gt;&lt;p&gt;啊实打实大打算阿萨德d&lt;/p&gt;&lt;pre class=&quot;brush:php;toolbar:false&quot;&gt;&lt;br/&gt;&lt;/pre&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;', '0', '3,', '', '', '0', '', '1');
INSERT INTO `jdi_article` VALUES ('2', 'dasdasd', '1', '4', '看完这一期的《我是歌手》，有个问题一直在思考，是谁在左右大众评审的耳朵？媒体舆论一直在争执“飙高音的歌手是否更适合这个舞台”，让大众评审现在在投票时对高音歌手出奇的挑剔，而对抒情歌手更多的青睐。一种“补偿”的心态似乎正在蔓延，可能会左右这一季很长时间。今天的官方微博以“绝世武功”做主题设计了海报，一场群雄纷争，混战厮杀就此开始。', '', '0', '28', '1422105661', '1422105737', '', '1', '#555', '#555', '&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center;&quot;&gt;&lt;img src=&quot;/jdicms/Uploads/editor/image/20150124/54c39bd2da13d.jpg&quot; title=&quot;54c39bd2da13d.jpg&quot; alt=&quot;14ce36d3d539b600c79c6193ea50352ac65cb740.jpg&quot; width=&quot;247&quot; height=&quot;355&quot; style=&quot;width: 247px; height: 355px;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(188, 211, 229);&quot;&gt;看完这一期的《我是歌手》，有个问题一直在思考，是谁在左右大众评审的耳朵？媒体舆论一直在争执“飙高音的歌手是否更适合这个舞台”，让大众评审现在在投票时对高音歌手出奇的挑剔，而对抒情歌手更多的青睐。一种“补偿”的心态似乎正在蔓延，可能会左右这一季很长时间。今天的官方微博以“绝世武功”做主题设计了海报，一场群雄纷争，混战厮杀就此开始。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(188, 211, 229);&quot;&gt;最终排名还是有点出乎意料：韩红1，黄丽玲2，李健3，胡彦斌4，孙楠5，古巨基6，张靓颖7。本人本场的个人排名完全不同：胡彦斌1，孙楠2，古巨基3，张靓颖4，韩红5，黄丽玲6，李健7。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(188, 211, 229);&quot;&gt;胡彦斌，赤裸裸地再次炫耀自己改编的才华，本季第一次摇滚演绎，非常出色，大胆突破自己，嗨动气氛。终于给小胡的嗓音找到了一个贴切的名词——金属拉丝般的嗓音，如滚石在金属上反复拉扯出的一道道痕迹，鸡皮疙瘩，却又上瘾般的美妙！摇滚新境界，当属今晚的胡彦斌。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(188, 211, 229);&quot;&gt;孙楠，流浪流浪，空灵高亢，这首歌的改编好听过小哥的版本。稳定的发挥反而给孙楠的排名带了弊病，在我歌的舞台，有一种“一如既往”叫排名不前！为胖楠有点叫屈，露背装还是蛮拼的，希望下一首孙楠大胆突破，焕然一新！&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(188, 211, 229);&quot;&gt;古巨基，从《好想好想》到《突然好想你》，一种蜕变的成熟，基仔很会唱歌，这首歌的演绎完全摆脱了五月天的影子，一如一首崭新的情歌，真的好听好听。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(188, 211, 229);&quot;&gt;张靓颖，飙高音有什么错，今晚排名第七有点吃亏，如今大家都在刻意躲避高音歌手，今晚的《离歌》其实表现得不错，结尾处那句直窜云霄的高音堪称完美，唢呐的搭配，增强了离悲的情绪。为什么会输，还是因为选歌不慎，这首烂透了的K歌之王，每个人都有自己不同的嘶吼，所以很少能赢得大家一致的惊叹和认同，选择《离歌》，女神，你是要离开我歌的节奏吗？&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(188, 211, 229);&quot;&gt;韩红，自费的马头琴乐队，有钱任性。韩红一直给我的感觉就是唱得不错，但是始终不走心。今晚的蒙语，有想法，但是还是显得做作，形式感的东西太多，什么时候让我们见识一下不同的韩红。40岁和50岁的选票帮了韩红一把，继续稳坐第一，难以撼动。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(188, 211, 229);&quot;&gt;黄丽玲，听重播第二遍才觉得有味道，与那英的嗓音类而不同，更有力量但是辨识度不足，今天的演绎犹如郁闷般的发泄却打在棉花上，爱上你等于爱上寂寞，无可又奈何，至于我把她排名第六，主要是因为我更喜欢那英那版的演绎。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(188, 211, 229);&quot;&gt;李健，本来非常期待的《贝加尔湖畔》原唱，却略显失望，不是他发挥不好，而是一百个人心中有一百个自己的贝加尔湖，李健的这曲不够纯净，暗含很多故事。在我心里，我的贝加尔湖是最纯净的，正如李维和周深版那样。不过健哥的确帅，诗人般的俊朗，他妈的还是清华的，让人心生嫉妒。&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(188, 211, 229);&quot;&gt;返场的李荣浩，平淡无奇的《笑忘书》，毫无亮点，难以逾越的王菲，唱完不罗嗦直接走掉，杰伦般的屌。如此的谢幕，只希望他“笑着忘掉在我歌的输”！&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(188, 211, 229);&quot;&gt;如今的我歌，胜负毫厘，不分伯仲，混战混战，下周再战，靓颖反弹，谁走好难！&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;', '0', '0', '', '', '0', '', '1');
INSERT INTO `jdi_article` VALUES ('3', '我的', '1', '4', '布里斯班的第三场比赛，体育场周边早早就涌动着红色的海洋，我努力要将眼睛看到的一切都刻在脑海里，多年后再追忆，会存留些什么呢？记忆一定会有磨损，比如如今再想起2004年8月7日中国亚洲杯决赛，我耳边似乎还能清晰地想起比赛行将结束时，耳机里急促的叮嘱，接收失败很难吗？未必，就看输给谁，在哪儿输，以怎样的方式输。', '', '0', '24', '1422105700', '1422105719', '', '1', '#555', '#555', '&lt;p&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-family: 华文仿宋; font-size: 18px;&quot;&gt;&lt;img src=&quot;http://ww2.sinaimg.cn/large/005AYphGjw1eoj050i7jgj30qe0hm79l.jpg&quot; real_src=&quot;http://ww2.sinaimg.cn/large/005AYphGjw1eoj050i7jgj30qe0hm79l.jpg&quot; alt=&quot;亚洲杯有感：请继续哀兵之态&quot; title=&quot;亚洲杯有感：请继续哀兵之态&quot; action-data=&quot;http%3A%2F%2Fww2.sinaimg.cn%2Flarge%2F005AYphGjw1eoj050i7jgj30qe0hm79l.jpg&quot; action-type=&quot;show-slide&quot; style=&quot;margin: 0px; padding: 0px; border: 0px; list-style: none; max-width: 100%;&quot;/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(188, 211, 229);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-family: 华文仿宋; font-size: 18px;&quot;&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&lt;/span&gt;&amp;nbsp;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 华文仿宋;&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;布里斯班的第三场比赛，体育场周边早早就涌动着红色的海洋，我努力要将眼睛看到的一切都刻在脑海里，多年后再追忆，会存留些什么呢？记忆一定会有磨损，比如如今再想起&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;2004&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;年&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;8&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;月&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;7&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;日中国亚洲杯决赛，我耳边似乎还能清晰地想起比赛行将结束时，耳机里急促的叮嘱，接收失败很难吗？未必，就看输给谁，在哪儿输，以怎样的方式输。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(188, 211, 229);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 华文仿宋;&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&lt;/span&gt;&amp;nbsp;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;2015&lt;/span&gt;&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 华文仿宋;&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;年&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;月&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;22&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;日，输给东道主，在阔别&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;125&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;个月的亚洲国家队顶级赛事的淘汰赛中输掉比赛，以拼尽全力的方式没能挽回败局，我们应该坦然接受这一结局，没有一句抱怨，暂且将疑问和不解包裹起来，此时不是战术复盘的最佳时刻。我们可以安慰自己，这不是个最好的结束方式，但可以是中国队再度出发的最佳起点，这份收获在出征澳大利亚前，在战胜乌兹别克斯坦前，都是断然不敢奢望的。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(188, 211, 229);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-family: 华文仿宋; font-size: 18px;&quot;&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&lt;/span&gt;&amp;nbsp;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 华文仿宋;&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;当我走进布里斯班大球场时，大门还未向球迷打开，场地内空空荡荡，前一天铺撒的绿色小颗粒将原本斑驳的球场装点得生机勃发。场地内正在彩排球队入场，《义勇军进行曲》昂然奏响，我在看台上用手机记录着这一瞬间，算计着中国队缺席这一时刻到底已经多久，真会出现大家普遍期待的转折时刻或是蚕变时刻吗？还会继续高歌猛进吗？我是悲观者，但并无妨碍我对比赛戏剧性的无限向往。赛前，一位前国脚非常肯定地对我说，中澳之间是有三球差距的，中国队如果输两个很正常的。当时，我无感，因为中国队此前连一个丈量差距的机会都没有。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(188, 211, 229);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-family: 华文仿宋; font-size: 18px;&quot;&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&lt;/span&gt;&amp;nbsp;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 华文仿宋;&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;就让这机会在我们眼前爆发吧。首发阵容前所未有的莫测，拿到手中习惯性地揣度佩兰的苦心，希望随着他的调整，中国队能踢得有模有样。开场的攻击性出乎意料，压迫性逼得自己比对手更早地发动马力，澳大利亚略显匆忙地进入比赛，躯体的僵硬和配合的局促让我们畅想很多，但比赛进行到这样的阶段，对抗的是球队的深度、厚度、气度，中国队能力的边界显露得太早，不足以支撑教练隐藏在背后的雄心。中国队可以多种姿态出战东道主，稳健中寻求控制，以控制自己和球进而达成对于比赛的局部控制，但初始的姿态是压迫性地试图在全场与对手争夺控制权，这需要充沛的体能，需要一以贯之的控制能力。很遗憾，中国队支撑了&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;15&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;分钟后，便将主动权交给了对手。不需要太细致的技术统计，仅从观感上便可以感知，两队差距之大。此时，你更会清晰地记得巴西世界杯上，澳大利亚输掉的三场比赛，&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;0&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;3&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;（西班牙）、&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;1&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;3&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;（智利）和&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;2&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;3&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;（荷兰），这是一支可以与世界强队拉开架势，站得稳，有攻防对抗能力甚至可以有世界波的球队，以上三个比分是他们与世界最高水准丈量的结果。&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;11&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;年来，第一场高强度、高压力事关生死的比赛，结果一切正常。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(188, 211, 229);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-family: 华文仿宋; font-size: 18px;&quot;&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&lt;/span&gt;&amp;nbsp;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 华文仿宋;&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;欠缺比赛，欠缺如此有价值的比赛，何谈质的转变，三场小组赛的价值在于目前算是可以平顺地赢下同等级对手了，虽小有波折，但球员们对于胜利的坚信程度在增强。经过这一场对抗，中国队内部的心态很会各不相同，吉翔赛后第一反应是，不该过度高看对手，这份源自场上的感受是不能被替代的。也有球员也会体会到对手的强大所在，对手施加的压力让中国队球员之间丧失了有效的关联，根本不可能从容地进行区域配合。澳大利亚比我们更习惯于此类比赛，比我们调整更快，更有效，这就是亚洲一流的水准，我们在短期内越过他们不现实。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(188, 211, 229);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-family: 华文仿宋; font-size: 18px;&quot;&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&lt;/span&gt;&amp;nbsp;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 华文仿宋;&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;其实，没打澳大利亚之前，中国队的亚洲杯赛已经赢了，而且取得了巨大的能效，同时证明中国队在赛场丧失的一切，必须在赛场上靠自己去夺回，没有捷径可言。三场九分，小组第一，过程清晰，至少逆转了国字号的美誉度，此前负面居多，而今可以平常心待之，再以批评中国足球错误而证明自己正确的习惯思维方式也可以慢慢寿终正寝了。但是，中国足球仍不具备高位运行的能力，澳大利亚人帮我们确认了这一点，理论上与日本、韩国和伊朗之战的机会还要再等等。如此，也就踏实了，稳住亚洲第二阵营的地位，常来八强行列就算正常表现，心怀憧憬，但不做虚妄。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(188, 211, 229);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-family: 华文仿宋; font-size: 18px;&quot;&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&lt;/span&gt;&amp;nbsp;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 华文仿宋;&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; line-height: 27px; font-size: 18px;&quot;&gt;能有澳大利亚亚洲杯不错结果，哀兵姿态该是主因之一，哀兵虽不保必胜，但哀兵同时具有的特质一点也不能少吧——专注、坚韧、老实、搏命。这样的心态不仅仅该长久属于中国国家足球队，更该属于即将迎来变革微妙期的中国足球改革吧。昂头活着，低头奋进，与中国足球共勉。&lt;/span&gt;&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;', '0', '0', '', '', '0', '', '1');
INSERT INTO `jdi_article` VALUES ('4', '大大说dasd 啊', '1', '4', '采访中，陈赫一直强调自己很希望家庭和事业能够两头兼顾，多一点时间陪爱人。殊不知那只是理想状态，因为忙于事业，他的童话婚姻在半年前已经破灭。13年的爱情长跑不易，经营一辈子的婚姻更难，想必在回忆以往甜蜜的同时，他一定也明白了这个道理。\r\n&lt;img src', '', '0', '39', '1422105770', '1422105770', '', '1', '#555', '#555', '&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;font-family:宋体;word-wrap: normal; word-break: normal;&quot;&gt;采访中，陈赫一直强调自己很希望家庭和事业能够两头兼顾，多一点时间陪爱人。殊不知那只是理想状态，因为忙于事业，他的童话婚姻在半年前已经破灭。13年的爱情长跑不易，经营一辈子的婚姻更难，想必在回忆以往甜蜜的同时，他一定也明白了这个道理。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-align: center; background-color: rgb(232, 220, 200);&quot;&gt;&lt;img src=&quot;http://s16.sinaimg.cn/bmiddle/001IgbT4gy6PoQkTD0b2f&amp;690&quot; real_src=&quot;http://s16.sinaimg.cn/bmiddle/001IgbT4gy6PoQkTD0b2f&amp;amp;690&quot; name=&quot;image_operate_72671421981490136&quot; alt=&quot;陈赫“贱”入佳境&quot; title=&quot;陈赫“贱”入佳境&quot; action-data=&quot;http%3A%2F%2Fs16.sinaimg.cn%2Fbmiddle%2F001IgbT4gy6PoQkTD0b2f%26690&quot; action-type=&quot;show-slide&quot; style=&quot;margin: 0px; padding: 0px; border: 0px; list-style: none; line-height: 1.5; text-indent: 28px;&quot;/&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;&amp;nbsp;&lt;wbr/&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; color: rgb(35, 59, 46); font-weight: bold; font-size: 10.5pt;&quot;&gt;“跑男”遇上《微爱》&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; color: rgb(231, 0, 18); font-size: 10.5pt;&quot;&gt;“我在跑男里就是真实的自己。”&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;光看《奔跑吧，兄弟》在重庆拍摄现场围观的里三层外三层“跑粉”，就知道这档节目有多火。粉丝们不遗余力地想穿过人山人海只为在人群中多看偶像一眼，一位《爱情公寓》的“忠粉”面露担心：“不知道贤哥的腰好了没？还好他陪伴节目走到了最后。”&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;在杭州拍摄的第一期节目，一上阵就要背起将近200斤的大妈、踩着&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt; text-indent: 21pt;&quot;&gt;硌死人的指压板飞奔，因为在学校时打排球腰上有伤，陈赫一背起大妈就觉得自己完了，但仍坚持录了几个环节。最后实在支撑不住，节目组只能叫急救车把他送进了医院。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;对这次掉链子，陈赫直呼遗憾，但接下来的几期他却越来越进入状态——不是表现得最好的那个，却是表现得最“贱”的那个。吃记忆飞饼的环节，队友紧张地盯着他吃东西的顺序，生怕因他的错误而被弹入水中，他却置队友的“生死”于不顾，表情妩媚，吃得自得其乐，搞得Angelababy和郑恺心都碎了。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;看了节目人们才发现，其实陈赫的那些微表情——挑眉、斜眼、扁嘴巴、贱笑——都是自然流露，没有一丝表演成分。而也因为他的天然“贱”，为他赢得了第一次触电的机会。&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;刚签约华谊不久，经纪人喊陈赫去试镜顾长卫导演的新电影《微爱之渐入佳境》，他觉得自己肯定不行，见了好几次导演，都很冷场。两人就那么干坐着，也不说话，大眼瞪小眼地互相看着。没想到最后得到通知：他虽不动声色却力压所有演员，拿到了男主角资格！毫无疑问，正是他在《爱情公寓》中“好男人”般的幽默和风趣与电影中的都市喜剧爱情相吻合。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;表演系出身，成功进军影坛，陈赫也算圆梦了。但他儿时的梦想本与演员无关。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-align: center; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; color: rgb(35, 59, 46); font-size: 10.5pt;&quot;&gt;&amp;nbsp;&lt;wbr/&gt;&lt;/span&gt;&lt;img src=&quot;http://s7.sinaimg.cn/mw690/001IgbT4gy6PoQ8A4yab6&amp;690&quot; real_src=&quot;http://s7.sinaimg.cn/mw690/001IgbT4gy6PoQ8A4yab6&amp;amp;690&quot; name=&quot;image_operate_47941421981491200&quot; alt=&quot;陈赫“贱”入佳境&quot; title=&quot;陈赫“贱”入佳境&quot; action-data=&quot;http%3A%2F%2Fs7.sinaimg.cn%2Fmw690%2F001IgbT4gy6PoQ8A4yab6%26690&quot; action-type=&quot;show-slide&quot; style=&quot;margin: 0px; padding: 0px; border: 0px; list-style: none; line-height: 1.5; text-indent: 28px;&quot;/&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-weight: bold; font-size: 10.5pt;&quot;&gt;舞台上当厨师&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; color: rgb(231, 0, 18); font-size: 10.5pt;&quot;&gt;“你猜我小时候的梦想是什么？是厨师。”&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;每个好男人都有一个能为爱人掌勺的厨师梦，陈赫也想当厨师，不过初衷是喂饱自己。&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;&amp;nbsp;&lt;wbr/&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;小时候，陈赫是出了名的捣蛋鬼，大院里谁的车坏了、谁家的玻璃碎了，肯定都是他带着那些孩子干的。淘气的孩子体力消耗大，饿得也快，小小年纪的他一人就能吃好几个人的饭。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;一年级时，爸妈上班不在家，他打电话给妈妈喊饿，问今天吃什么。妈妈说冰箱里有菜，把菜的做法给他讲了一遍，让他试着自己做。没想陈赫还真有做饭的天赋，做的菜不仅美味而且卖相也大赞。从那时起他便养成了一个习惯：不管什么菜谱，只要听一遍，就能自己做出来。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;到了高三，父母开始关心起陈赫的将来。妈妈拉着他问：“儿子，你将来想干啥？”陈赫心想，如果我说想当厨师，他们肯定不同意，就敷衍道：“我要当演员，咱们一家都是演员，我肯定也要当啊。”&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;他的戏言却被妈妈当了真，请假陪着儿子去北京和上海考试，从中央戏剧学院、北京电影学院，一路来到上海戏剧学院。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;这三所学校在从未学过表演的陈赫心里，简直是高不可攀的神坛。幸好他从小就跟随妈妈在话剧团的舞台边长大，耳濡目染，不算两眼一抹黑。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;当年考试的情景陈赫依然记忆犹新。“有天在中戏考完二试，看到我妈在巷口等我。冬天，风吹得很烈，我妈一个人在那儿站着，当时我心里就很感动，心想不管怎么样我都要拼一次。”&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;考“上戏”初试那天，题目是表演“看榜”。所有人都拥上去看黑板，只有陈赫往后退，蹲在后面。等一起考试的学生表演完，陈赫才站起来，看一眼就走，什么夸张的表演都没有，却让老师记住了这个聪明的小孩。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;等到最后口试时，老师拿着一张写着电话号码的纸找到他：“这是我们教务处的号码，你是我们第一个破格录取的学生。只要你考过了文化课，打这个电话就可以来上学了。”陈赫把纸条揣在兜里，心跳得很厉害。走到校门口，看到妈妈，拿出这张纸，什么话都没说，眼泪却飞出来了。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;&amp;nbsp;&lt;wbr/&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-weight: bold; font-size: 10.5pt;&quot;&gt;幸遇《爱情公寓》&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; color: rgb(231, 0, 18); font-size: 10.5pt;&quot;&gt;“我不可能一辈子演曾小贤，我什么角色都会尝试，但是我希望以后如果提到中国喜剧的话，观众能想起有一部《爱情公寓》这样的戏。”&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;“我是个幸运的人。”陈赫一直强调。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;毕业之后他进入上海话剧中心，第一部戏就是在知名青年导演何念的话剧《疯狂的疯狂》中扮演男一号，这个角色本属于黄渤。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;演完《疯狂的疯狂》，《爱情公寓》就来了。试的第一个角色是陆展博，试着试着，他觉得这个角色和自己不对口，台词怎么念都念不出感觉，只能放弃：“导演，对不起，我达不到你的要求，我走了。”谁知道导演追出来问：“我这里有一个主持人的角色，你帮我读一句话。”那句话就是曾小贤在《爱情公寓》里说得最多的标志性语言：“欢迎收听《你的月亮我的心》，好男人就是我，我就是曾小贤。”陈赫刚念完，导演就说：“你可以来我们剧组了。”&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;&amp;nbsp;&lt;wbr/&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;《爱情公寓》的走红，和剧中个性相异的几位主演有着莫大关联。曾小贤这个角色最为出彩。剧中的曾小贤很敏感，是一个老好人，特别爱管闲事，但每次出的都是馊主意。“他总认为自己是最棒的，其实他是一个失败者，他主持的节目永远是在午夜十二时开始，他做的事是帮助人家解决爱情问题，但是自己的爱情问题一塌糊涂。”&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;陈赫把这个角色演得活脱，他觉得自己入戏“太深”，甚至生活都在向曾小贤靠拢，“以前不是那么像，但演了5年后大家都说越来越像了，以前大学的时候比较宅，演了曾小贤之后我自己的性格也变得越来越开朗和幽默了。”&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;&amp;nbsp;&lt;wbr/&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-weight: bold; font-size: 10.5pt;&quot;&gt;初恋一辈子&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; color: rgb(231, 0, 18); font-size: 10.5pt;&quot;&gt;“每次谈起这件事，我都骄傲得恨不得用下巴俯视世界——哥把初恋谈了13年，最后修成正果了，哥实在觉得自己帅爆了！”&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;和把自己的爱情搞得一塌糊涂的曾小贤不同，陈赫的爱情拥有让人羡慕的所有关键词——一见钟情、初恋、13年爱情长跑、一辈子。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;14年前，陈赫对许婧一见钟情。几个同学在一起打水枪，陈赫一眼就看到了许婧，从此便在同学的关注和老师的暴怒中开始了坏男孩和乖&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;女孩的早恋。“其实这种感情是非常单纯和透明的，无非是看到她就开心，想呆在她身边跟她说说话。那么多人断言我们无法长远，我就算赌气，也要把自己变好，让自己变得配得上这份感情，证明给全世界看她跟我在一起一定会幸福。”&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;陈赫在上海戏剧学院上学期间，许婧考入浙江传媒学院。几乎每个周末他都会坐火车去杭州看女友，“周日晚上再坐火车回学校，除了生病、有事的几次缺席，那3年里我为铁道部贡献了144张车票。”&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;毕业后经过5年打拼，2013年9月陈赫终于和许婧在泰国普吉岛完婚。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;婚后，他毫不讳言自己是“妻管严”，甚至因为经常跪键盘而自嘲是“常跪”，还认为怕老婆是好男人基本标志。陈赫最想提醒广大男同胞：“千万不要和女人讲道理。也许你的道理是对的，但讲道理这件事本身就错大了。对女人而言，她肯定不是不明白道理，她只是需要证明：在你心里她比道理重要。说到底，让着一个你爱的人，有多难呢？”&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;曾干过和老婆论战这种蠢事的他，如今总结的经验就是学会看老婆脸色。“要是不认同老婆的做法，就找她心情好的时候半开玩笑地教育她。她多半会委屈地撒娇说：‘好嘛好嘛，以后不犯了。’”如果发生争执，多数情况下陈赫会拿出“常跪”的气概来低头认错，“哄老婆开心有很多方式：给她做一顿爱心晚餐，或者替她把淘宝账户购物车里的账结了……”&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;不过在和老婆的“战争”中他也有罕见的胜利，“我老婆身高1.69米，体重不到100斤，她还要减肥。后来我就跟她说：‘从现在开始你吃什么我吃什么，你不吃我也不吃，如果在片场饿到晕倒，我就说是老婆逼我减肥’。两天下来，老婆被我吓到了，废除了减肥计划。”&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; text-indent: 21pt; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;生活中的陈赫其实很简单，他喜欢打游戏、看漫画书、玩微博、煮饭，还爱养宠物。在他福州的家里，有五六条金毛猎犬，而在上海的家里，也有猫有狗，其乐无穷。在他的微博空间里，有不少猫猫狗狗的照片，还有不少自己和宠物的合影。他在图片下面配文字，有空了会替它们写剧本，故事生动又好玩，被不少网友评论为“很有爱”。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;刚结束跑男的拍摄又要到处宣传新电影《微爱之渐入佳境》，陈赫直言自己很忙，但他还是希望能够有多点的时间陪家人，“我想事业和家庭两头兼顾，我给自己立下一个目标，不要那么忙。每年拍8个月的戏，其余时间就带着爱人和父母去旅游。”虽然身在演艺圈，却没有大红大紫的野心，这是陈赫最享受的生活状态。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;&amp;nbsp;&lt;wbr/&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; color: rgb(255, 0, 0); font-size: 10.5pt;&quot;&gt;明星面对面&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;Q=家人杂志&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;&amp;nbsp;&lt;wbr/&gt;A&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;=陈赫&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;Q：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;第一部电影就出演男主角，你紧张过吗？在和Angelababy的合作过程中有什&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;么有趣的事情发生？&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;A：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;非常紧张，开机第一个镜头我整个人一直在发抖。和baby合作很愉快，片场太多搞笑&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;的事了，比如我们一起打游戏。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;Q：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;现在最后一期的《奔跑吧，兄弟》拍摄已经结束，你最大的收获是什么？&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;A：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;是友情，我们几个人从最开始有些互相都不认识，现在成为了家人一样的存在。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;Q：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;除了自己，你最爱的演员是谁？为什么？&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;A：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;周星驰，觉得他很厉害，能够坚持做喜剧做了那么多年，而且一直有新的东西出来。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;Q：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;每个人都可能经历波峰和波谷，你觉得你的波谷在什么时候？现在是你的波峰吗？&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;A：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;其实一路走来都还算顺利，我觉得没有真正波谷的时候吧，虽然有起有落，但都是正常&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;的。至于波峰，我也觉得自己没有到最好的时候，还是一步一个脚印，希望未来越来越好。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;Q：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;通常你会因为什么事情生气或高兴？怎么处理那些负面情绪呢？&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;A：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;很多事情啊，吃到美食会开心，终于能睡个好觉也会很开心。有负面情绪的时候我会跟&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;身边人说出来，不会憋在心里。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;Q：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;最害怕什么？&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;A：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;我爱的人生病，身体不健康。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;Q：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;用一句话总结工作中的自己，你会怎么说？&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;A：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;棒棒哒！&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;Q：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;如果没有选择做演员，你想你现在最有可能在做什么？&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;A：&lt;/span&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;我现在可能真成厨师了吧，哈哈哈。&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;margin-top: 0px; padding: 0px; border: 0px; list-style: none; word-wrap: normal; word-break: normal; line-height: 21px; color: rgb(70, 70, 70); font-family: &amp;#39;Microsoft YaHei&amp;#39;, &amp;#39;Helvetica Neue&amp;#39;, SimSun; font-size: 14px; white-space: normal; background-color: rgb(232, 220, 200);&quot;&gt;&lt;span style=&quot;word-wrap: normal; word-break: normal; font-family: 宋体; font-size: 10.5pt;&quot;&gt;（版权所有，严禁一切商业用途的转载&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;', '0', '0', '', '', '0', '', '0');

-- -----------------------------
-- Table structure for `jdi_article_picture`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_article_picture`;
CREATE TABLE `jdi_article_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `uid` int(10) unsigned NOT NULL COMMENT '发布用户id',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `link` varchar(255) NOT NULL COMMENT '外链',
  `deadline` int(10) NOT NULL COMMENT '截止时间',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览数量',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '更新时间',
  `url` varchar(255) NOT NULL COMMENT '内容页面url',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  `picture` text COMMENT '图片',
  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '权重',
  `is_up` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `list_color` char(10) NOT NULL COMMENT '列表页颜色',
  `title_color` char(10) NOT NULL COMMENT '内容页颜色',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `jdi_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_attribute`;
CREATE TABLE `jdi_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL DEFAULT '',
  `validate_time` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `error_info` varchar(100) NOT NULL DEFAULT '',
  `validate_type` varchar(25) NOT NULL DEFAULT '',
  `auto_rule` varchar(100) NOT NULL DEFAULT '',
  `auto_time` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `auto_type` varchar(25) NOT NULL DEFAULT '',
  `validate_condition` tinyint(1) NOT NULL DEFAULT '0' COMMENT '验证条件',
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=298 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `jdi_attribute`
-- -----------------------------
INSERT INTO `jdi_attribute` VALUES ('82', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '18', '1', '1', '1418891555', '1418802074', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('83', 'uid', '发布用户id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '18', '1', '1', '1418803756', '1418802189', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('84', 'category_id', '所属分类', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '18', '1', '1', '1418802338', '1418802338', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('85', 'description', '描述', 'varchar(255) NOT NULL', 'string', '', '内容描述', '1', '', '18', '0', '1', '1418966250', '1418802392', '0,255', '3', '', 'length', '', '3', 'function', '2');
INSERT INTO `jdi_attribute` VALUES ('86', 'link', '外链', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '18', '0', '1', '1418865687', '1418802915', 'url', '3', 'url格式错误', 'regex', '', '3', 'function', '2');
INSERT INTO `jdi_attribute` VALUES ('87', 'deadline', '截止时间', 'int(10) NOT NULL', 'date', '', '文章的显示截至日期,不写则代表永久有效', '1', '', '18', '0', '1', '1418890382', '1418803034', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('88', 'view', '浏览数量', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '1', '', '18', '0', '1', '1418866062', '1418803184', '/^([1-9]\\d*)|0$/', '3', '浏览次数必须是正整数', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('89', 'create_time', '创建时间', 'int(10) UNSIGNED NOT NULL', 'date', '', '如果不写则默认为当前时间', '2', '', '18', '0', '1', '1418865962', '1418803555', '', '3', '', 'regex', 'time', '1', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('90', 'update_time', '更新时间', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '18', '0', '1', '1418803597', '1418803597', '', '3', '', 'regex', 'time', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('91', 'url', '内容页面url', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '18', '0', '1', '1418866509', '1418866472', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('92', 'status', '状态', 'tinyint(1) UNSIGNED NOT NULL', 'num', '1', '状态', '0', '', '18', '0', '1', '1418887579', '1418882734', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('93', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '20', '1', '1', '1418891555', '1418802074', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('94', 'uid', '发布用户id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '20', '1', '1', '1418803756', '1418802189', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('95', 'category_id', '所属分类', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '20', '1', '1', '1418802338', '1418802338', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('96', 'description', '描述', 'varchar(255)  NOT NULL', 'autoText', '', '内容描述,255个字符以内', '1', '', '20', '0', '1', '1421130059', '1418802392', '0,255', '3', '长度不能超过255个字符', 'length', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('97', 'link', '外链', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '20', '0', '1', '1420596778', '1418802915', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('98', 'deadline', '截止时间', 'int(10) NOT NULL', 'date', '', '文章的显示截至日期,不写或者显示1970-01-01则代表永久有效', '1', '', '20', '0', '1', '1418979835', '1418803034', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('99', 'view', '浏览数量', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '1', '', '20', '0', '1', '1418866062', '1418803184', '/^([1-9]\\d*)|0$/', '3', '浏览次数必须是正整数', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('100', 'create_time', '创建时间', 'int(10) UNSIGNED NOT NULL', 'date', '', '如果不写则默认为当前时间', '2', '', '20', '0', '1', '1418865962', '1418803555', '', '3', '', 'regex', 'time', '1', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('101', 'update_time', '更新时间', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '20', '0', '1', '1418803597', '1418803597', '', '3', '', 'regex', 'time', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('102', 'url', '内容页面url', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '20', '0', '1', '1418866509', '1418866472', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('103', 'status', '状态', 'tinyint(1) UNSIGNED NOT NULL', 'num', '1', '状态', '0', '', '20', '0', '1', '1418887579', '1418882734', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('104', 'title_color', '内容页标题颜色', 'char(10)  NOT NULL', 'color', '\'#555\'', '默认值代表不设置', '1', '', '20', '0', '1', '1419255883', '1418954725', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('105', 'list_color', '列表页标题颜色', 'char(10)  NOT NULL', 'color', '\'#555\'', '默认值代表不设置', '1', '', '20', '0', '1', '1419255901', '1418954751', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('106', 'content', '文章内容', 'text NOT NULL', 'editor', '', '', '1', '', '20', '1', '1', '1418954824', '1418954824', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('107', 'is_up', '是否置顶', 'tinyint(2) NOT NULL', 'bool', '0', '', '1', '0:否\r\n1:是', '20', '0', '1', '1418956979', '1418955083', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('108', 'position', '推荐位', 'varchar(100) NOT NULL', 'checkbox', '0', '', '1', '[DOCUMENT_POSITION]', '20', '0', '1', '1419138707', '1418955236', '', '3', '', 'regex', 'position_parse', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('131', 'url', '内容页面url', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '22', '0', '1', '1418866509', '1418866472', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('130', 'update_time', '更新时间', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '22', '0', '1', '1418803597', '1418803597', '', '3', '', 'regex', 'time', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('128', 'view', '浏览数量', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '1', '', '22', '0', '1', '1418866062', '1418803184', '/^([1-9]\\d*)|0$/', '3', '浏览次数必须是正整数', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('127', 'deadline', '截止时间', 'int(10) NOT NULL', 'date', '', '文章的显示截至日期,不写则代表永久有效', '1', '', '22', '0', '1', '1418890382', '1418803034', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('126', 'link', '外链', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '22', '0', '1', '1418865687', '1418802915', 'url', '3', 'url格式错误', 'regex', '', '3', 'function', '2');
INSERT INTO `jdi_attribute` VALUES ('125', 'description', '描述', 'varchar(255) NOT NULL', 'string', '', '内容描述', '1', '', '22', '0', '1', '1418966250', '1418802392', '0,255', '3', '', 'length', '', '3', 'function', '2');
INSERT INTO `jdi_attribute` VALUES ('124', 'category_id', '所属分类', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '22', '1', '1', '1418802338', '1418802338', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('123', 'uid', '发布用户id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '22', '1', '1', '1418803756', '1418802189', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('122', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '22', '1', '1', '1418891555', '1418802074', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('129', 'create_time', '创建时间', 'int(10) UNSIGNED NOT NULL', 'date', '', '如果不写则默认为当前时间', '2', '', '22', '0', '1', '1418865962', '1418803555', '', '3', '', 'regex', 'time', '1', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('132', 'status', '状态', 'tinyint(1) UNSIGNED NOT NULL', 'num', '1', '状态', '0', '', '22', '0', '1', '1418887579', '1418882734', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('133', 'file', '文件', 'int(10) UNSIGNED NOT NULL', 'file', '', '', '1', '', '22', '1', '1', '1418979125', '1418978785', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('134', 'cover', '封面', 'varchar(150) NOT NULL', 'picture', '', '', '1', '', '20', '0', '1', '1421118390', '1418979727', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('135', 'extend', '扩展统计字段', 'text NOT NULL', 'textarea', '', '', '0', '', '20', '0', '1', '1418986871', '1418986871', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('239', 'auto_image', '提取封面图片', 'mediumint(8) UNSIGNED NOT NULL', 'autoImage', '0', '0表示不提取,如果设置了封面图片则提取无效', '1', '', '20', '0', '1', '1421128801', '1421122745', '/^([1-9]\\d*)|0$/', '3', '图片提取必须是正整数或者0', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('238', 'keyword', '关键词', 'varchar(255) NOT NULL', 'keyword', '', '', '1', 'title\r\ncontent', '20', '0', '1', '1421119003', '1421119003', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('237', 'weight', '权重', 'int(10) UNSIGNED NOT NULL', 'num', '0', '权重越大,排位越靠前', '1', '', '22', '0', '1', '1422868639', '1421066265', '', '3', '', 'regex', '', '1', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('236', 'weight', '权重', 'int(10) UNSIGNED NOT NULL', 'num', '0', '权重越大,排位越靠前', '1', '', '18', '0', '1', '1421066543', '1421066228', '', '3', '', 'regex', 'setWeight', '1', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('235', 'weight', '权重', 'int(10) UNSIGNED NOT NULL', 'num', '0', '权重越大,文章排位越靠前', '1', '', '20', '0', '1', '1421128753', '1421066182', '/^(-?[1-9]\\d*)|0$/', '3', '权重必须是数字', 'regex', 'setWeight', '1', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('240', 'url', '内容页面url', 'varchar(255) NOT NULL', 'string', '', '', '0', '', '32', '0', '1', '1418866509', '1418866472', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('241', 'update_time', '更新时间', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '32', '0', '1', '1418803597', '1418803597', '', '3', '', 'regex', 'time', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('242', 'view', '浏览数量', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '1', '', '32', '0', '1', '1418866062', '1418803184', '/^([1-9]\\d*)|0$/', '3', '浏览次数必须是正整数', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('243', 'deadline', '截止时间', 'int(10) NOT NULL', 'date', '', '文章的显示截至日期,不写则代表永久有效', '1', '', '32', '0', '1', '1418890382', '1418803034', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('244', 'link', '外链', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '32', '0', '1', '1418865687', '1418802915', 'url', '3', 'url格式错误', 'regex', '', '3', 'function', '2');
INSERT INTO `jdi_attribute` VALUES ('245', 'description', '描述', 'varchar(255) NOT NULL', 'string', '', '内容描述', '1', '', '32', '0', '1', '1418966250', '1418802392', '0,255', '3', '', 'length', '', '3', 'function', '2');
INSERT INTO `jdi_attribute` VALUES ('246', 'category_id', '所属分类', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '32', '1', '1', '1418802338', '1418802338', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('247', 'uid', '发布用户id', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '32', '1', '1', '1418803756', '1418802189', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('248', 'title', '标题', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '32', '1', '1', '1418891555', '1418802074', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('249', 'create_time', '创建时间', 'int(10) UNSIGNED NOT NULL', 'date', '', '如果不写则默认为当前时间', '2', '', '32', '0', '1', '1418865962', '1418803555', '', '3', '', 'regex', 'time', '1', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('250', 'status', '状态', 'tinyint(1) UNSIGNED NOT NULL', 'num', '1', '状态', '0', '', '32', '0', '1', '1418887579', '1418882734', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('251', 'picture', '图片', 'text', 'multiPicture', '', '', '1', '', '32', '1', '1', '1421650895', '1418978785', '', '3', '您至少上传一张图片', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('252', 'weight', '权重', 'int(10) NOT NULL', 'num', '0', '权重越大,排位越靠前', '1', '', '32', '0', '1', '1421661867', '1421066265', '/^(-?[1-9]\\d*)|0$/', '3', '权重必须是数字', 'regex', '', '1', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('253', 'is_up', '是否置顶', 'tinyint(2) NOT NULL', 'bool', '0', '', '1', '0:否\r\n1:是', '32', '0', '1', '1421666583', '1421661622', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('254', 'list_color', '列表页颜色', 'char(10)  NOT NULL', 'color', '', '', '1', '', '32', '0', '1', '1421661707', '1421661646', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('255', 'title_color', '内容页颜色', 'char(10)  NOT NULL', 'color', '', '', '1', '', '32', '0', '1', '1421661687', '1421661687', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('256', 'is_up', '是否置顶', 'tinyint(2) NOT NULL', 'bool', '0', '', '1', '0:否\r\n1:是', '22', '0', '1', '1422869437', '1422241670', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('257', 'uid', '产品发布者', 'int(10) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '33', '0', '1', '1425109188', '1425109188', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('258', 'name', '产品名称', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '33', '1', '1', '1425109219', '1425109219', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('259', 'company', '公司名称', 'varchar(50) NOT NULL', 'string', '', '', '0', '', '33', '1', '1', '1425628984', '1425109344', '', '3', '', 'regex', 'get_company_name', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('260', 'introduce', '产品介绍', 'text NOT NULL', 'simpleEditor', '', '', '1', '', '33', '1', '1', '1425109424', '1425109424', '', '3', '', 'regex', '', '3', 'function', '1');
INSERT INTO `jdi_attribute` VALUES ('296', 'create_time', '创建时间', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '34', '0', '1', '1425701686', '1425701686', '', '3', '', 'regex', 'time', '1', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('297', 'update_time', '更新时间', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '34', '0', '1', '1425701701', '1425701701', '', '3', '', 'regex', 'time', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('263', 'picture', '产品封面', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '33', '1', '1', '1425629001', '1425109593', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('264', 'picture', '企业logo', 'int(10) UNSIGNED NOT NULL', 'picture', '', '', '1', '', '34', '0', '1', '1425628902', '1425110016', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('265', 'name', '企业全称', 'varchar(255) NOT NULL', 'string', '', '请您填写企业的全称', '1', '', '34', '1', '1', '1425110118', '1425110118', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('266', 'introduce', '企业介绍', 'text NOT NULL', 'simpleEditor', '', '', '1', '', '34', '0', '1', '1425110160', '1425110160', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('267', 'telephone', '联系电话', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '34', '0', '1', '1425110300', '1425110300', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('268', 'uid', '关联用户', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '34', '0', '1', '1425116921', '1425116921', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('269', 'create_time', '创建时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '33', '0', '1', '1425182665', '1425182665', '', '3', '', 'regex', 'time', '1', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('270', 'update_time', '更新时间', 'int(10) NOT NULL', 'datetime', '', '', '0', '', '33', '0', '1', '1425182836', '1425182677', '', '3', '', 'regex', 'time', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('271', 'status', '状态', 'tinyint(1)', 'num', '1', '', '0', '', '33', '0', '1', '1425189430', '1425189430', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('276', 'name', '名称', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '37', '1', '1', '1425457369', '1425353140', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('274', 'status', '状态', 'tinyint(1)', 'num', '', '', '0', '', '34', '0', '1', '1425357901', '1425352502', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('277', 'content', '内容', 'text NOT NULL', 'editor', '', '', '1', '', '37', '1', '1', '1425457991', '1425353171', '10,500', '3', '长度必须大于10个字符', 'length', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('278', 'create_time', '创建时间', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '37', '0', '1', '1425366334', '1425362012', '', '1', '', 'regex', 'time', '1', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('279', 'update_time', '更新时间', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '37', '0', '1', '1425366370', '1425362392', '', '2', '', 'regex', 'time', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('280', 'status', '状态', 'tinyint(1)', 'num', '1', '', '0', '', '37', '0', '1', '1425626655', '1425364208', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('281', 'uid', '发布者', 'int(10) UNSIGNED NOT NULL', 'num', '', '', '0', '', '37', '1', '1', '1425368005', '1425368005', '', '3', '', 'regex', '', '3', 'field', '0');
INSERT INTO `jdi_attribute` VALUES ('282', 'category', '类别', 'char(50) NOT NULL', 'select', '', '', '1', '[COMPANY_CATEGORY]', '34', '1', '1', '1425522186', '1425522186', '', '3', '', 'regex', '', '3', 'function', '1');
INSERT INTO `jdi_attribute` VALUES ('283', 'category', '产品类型', 'char(50) NOT NULL', 'select', '', '', '1', '[PRODUCTION_CATEGORY]', '33', '1', '1', '1425522876', '1425522876', '', '3', '', 'regex', '', '3', 'function', '1');
INSERT INTO `jdi_attribute` VALUES ('284', 'burdening', '配料', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '33', '0', '1', '1425607061', '1425607061', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('285', 'point', '坐标', 'char(80)  NOT NULL', 'point', '', '', '1', '', '34', '0', '1', '1425620963', '1425607830', '/^\\d+\\.\\d+,\\d+\\.\\d+$/', '3', '坐标格式不正确', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('295', 'place', '公司地址', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '34', '1', '1', '1425696170', '1425696170', '', '3', '', 'regex', '', '3', 'function', '1');
INSERT INTO `jdi_attribute` VALUES ('288', 'is_top', '是否置顶', 'tinyint(1)', 'num', '0', '', '0', '', '37', '0', '1', '1425609956', '1425609956', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('289', 'recommend', '是否推荐', 'tinyint(1)', 'num', '0', '', '0', '', '37', '0', '1', '1425609992', '1425609992', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('290', 'excellent', '是否设精', 'tinyint(1)', 'num', '0', '', '0', '', '37', '0', '1', '1425610059', '1425610059', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('293', 'recommend', '是否推荐', 'tinyint(1) UNSIGNED NOT NULL', 'num', '0', '', '0', '', '33', '0', '1', '1425632867', '1425632867', '', '3', '', 'regex', '', '3', 'function', '0');
INSERT INTO `jdi_attribute` VALUES ('294', 'is_top', '置顶', 'tinyint(1) UNSIGNED NOT NULL', 'num', '', '', '0', '', '33', '0', '1', '1425632952', '1425632952', '', '3', '', 'regex', '', '3', 'function', '0');

-- -----------------------------
-- Table structure for `jdi_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_auth_extend`;
CREATE TABLE `jdi_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `jdi_auth_extend`
-- -----------------------------
INSERT INTO `jdi_auth_extend` VALUES ('11', '29', '2');
INSERT INTO `jdi_auth_extend` VALUES ('12', '35', '2');
INSERT INTO `jdi_auth_extend` VALUES ('13', '33', '2');

-- -----------------------------
-- Table structure for `jdi_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_auth_group`;
CREATE TABLE `jdi_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jdi_auth_group`
-- -----------------------------
INSERT INTO `jdi_auth_group` VALUES ('10', 'admin', '1', '超级管理员', '', '1', '358,359,360,361,362,363,364,365,366,367,368,369,370,371,372,373,374,375,376,377,378,379,380,381,382,383,384,385,386,387,388,389,390,391,392,393,394,395,396,397,398,399,400,401,402,403,404,405,406,407,408,409,410,411,412,413,414,415,417,419,421,423,424,425,426');
INSERT INTO `jdi_auth_group` VALUES ('11', 'admin', '1', '测试', '测试', '1', '');
INSERT INTO `jdi_auth_group` VALUES ('12', 'admin', '1', '佰邦管理员', '', '1', ',15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,45,47,48,50,66,68');
INSERT INTO `jdi_auth_group` VALUES ('13', 'admin', '1', '企业用户', '企业用户组', '1', '67');

-- -----------------------------
-- Table structure for `jdi_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_auth_group_access`;
CREATE TABLE `jdi_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jdi_auth_group_access`
-- -----------------------------
INSERT INTO `jdi_auth_group_access` VALUES ('36', '11');
INSERT INTO `jdi_auth_group_access` VALUES ('36', '12');
INSERT INTO `jdi_auth_group_access` VALUES ('39', '13');
INSERT INTO `jdi_auth_group_access` VALUES ('40', '13');
INSERT INTO `jdi_auth_group_access` VALUES ('44', '13');

-- -----------------------------
-- Table structure for `jdi_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_auth_rule`;
CREATE TABLE `jdi_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jdi_auth_rule`
-- -----------------------------
INSERT INTO `jdi_auth_rule` VALUES ('1', 'admin', '1', 'Admin/menu/add', '新增', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('2', 'admin', '1', 'Admin/menu/del', '删除', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('3', 'admin', '1', 'Admin/menu/import', '导入', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('4', 'admin', '1', 'Admin/menu/edit', '编辑', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('5', 'admin', '1', 'Admin/user/index', '用户信息', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('6', 'admin', '1', 'Admin/user/action', '用户行为', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('7', 'admin', '1', 'Admin/authManager/index', '权限管理', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('8', 'admin', '1', 'Admin/action/actionlog', '行为日志', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('9', 'admin', '1', 'Admin/user/updatePassword', '修改密码', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('10', 'admin', '1', 'Admin/user/updateNickname', '修改昵称', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('11', 'admin', '1', 'Admin/config/group', '分组管理', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('12', 'admin', '1', 'Admin/config/index', '配置管理', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('13', 'admin', '1', 'Admin/model/index', '模型管理', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('14', 'admin', '1', 'Admin/menu/sort', '排序', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('15', 'admin', '1', 'Admin/link/add', '添加', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('16', 'admin', '1', 'Admin/link/edit', '编辑', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('17', 'admin', '1', 'Admin/link/changeStatus\r', '禁用', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('18', 'admin', '1', 'Admin/link/del\r', '删除', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('19', 'admin', '1', 'Admin/link/sort', '排序', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('20', 'admin', '1', 'Admin/content/news', '查看', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('21', 'admin', '1', 'Admin/content/add', '添加', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('22', 'admin', '1', 'Admin/content/edit', '编辑', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('23', 'admin', '1', 'Admin/content/changeStatus', '改变状态', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('24', 'admin', '1', 'Admin/content/up', '置顶', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('25', 'admin', '1', 'Admin/content/del', '删除', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('26', 'admin', '1', 'Admin/category/add\r', '添加', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('27', 'admin', '1', 'Admin/category/edit\r', '编辑', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('28', 'admin', '1', 'Admin/category/changeStatus\r', '禁用', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('29', 'admin', '1', 'Admin/category/delete\r', '删除', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('30', 'admin', '1', 'Admin/category/sort\r', '排序', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('31', 'admin', '1', 'Admin/category/clearCache\r', '清除缓存', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('32', 'admin', '1', 'Admin/category/import', '导入', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('33', 'admin', '1', 'Admin/model/add', '添加模型', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('34', 'admin', '1', 'Admin/model/edit', '编辑模型', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('35', 'admin', '1', 'Admin/model/generate', '生成模型', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('36', 'admin', '1', 'Admin/attribute/add', '添加属性', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('37', 'admin', '1', 'Admin/attribute/edit', '编辑属性', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('38', 'admin', '1', 'Admin/attribute/index', '属性管理', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('39', 'admin', '1', 'Admin/config/add', '新增配置', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('40', 'admin', '1', 'Admin/config/edit', '编辑配置', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('41', 'admin', '1', 'Admin/config/save', '批量保存', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('42', 'admin', '1', 'Admin/config/del', '删除配置', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('43', 'admin', '1', 'Admin/config/sort', '排序', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('44', 'admin', '2', 'Admin/Index/index', '首页', '-1', '');
INSERT INTO `jdi_auth_rule` VALUES ('45', 'admin', '1', 'Admin/content/index', '内容管理', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('46', 'admin', '2', 'Admin/public/index', '扩展', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('47', 'admin', '1', 'Admin/link/index', '链接管理', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('48', 'admin', '1', 'Admin/category/index', '分类管理', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('49', 'admin', '1', 'Admin/menu/index', '菜单管理', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('50', 'admin', '1', 'Admin/database/exportIndex', '备份数据库', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('51', 'admin', '1', 'Admin/database/importIndex', '还原数据库', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('52', 'admin', '1', 'Admin/authManager/createGroup', '创建用户组', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('53', 'admin', '1', 'Admin/authManager/access', '访问授权', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('54', 'admin', '1', 'Admin/authManager/category', '分类授权', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('55', 'admin', '1', 'Admin/addons/index', '插件管理', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('56', 'admin', '1', 'Admin/addons/hooks', '钩子管理', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('57', 'admin', '1', 'Admin/addons/create', '创建', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('58', 'admin', '1', 'Admin/addons/preview', '预览', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('59', 'admin', '1', 'Admin/addons/config', '设置', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('60', 'admin', '1', 'Admin/addons/edithook', '编辑钩子', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('61', 'admin', '1', 'Admin/addons/addhook', '添加钩子', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('62', 'admin', '1', 'Admin/temp/editTemp', '编辑模版', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('63', 'admin', '1', 'Admin/temp/index', '模版设置', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('64', 'admin', '1', 'Admin/module/index', '模块管理', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('65', 'admin', '2', 'Admin/dispatch/execute_module?_module=Goods&_controller=index&_action=index', '商品管理', '-1', '');
INSERT INTO `jdi_auth_rule` VALUES ('66', 'admin', '2', 'Admin/addonsBack/adminList', '插件', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('67', 'admin', '2', 'Admin/dispatch/execute_module?_module=Person&_controller=index&_action=index', '企业中心', '1', '');
INSERT INTO `jdi_auth_rule` VALUES ('68', 'admin', '2', 'Admin/dispatch/execute_module?_module=BaiBang&_controller=index&_action=index', '佰帮', '1', '');

-- -----------------------------
-- Table structure for `jdi_base_article`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_base_article`;
CREATE TABLE `jdi_base_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `uid` int(10) unsigned NOT NULL COMMENT '发布用户id',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `link` varchar(255) NOT NULL COMMENT '外链',
  `deadline` int(10) NOT NULL COMMENT '截止时间',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览数量',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '更新时间',
  `url` varchar(255) NOT NULL COMMENT '内容页面url',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  `weight` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '权重',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `jdi_comment`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_comment`;
CREATE TABLE `jdi_comment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `topic_table` char(20) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `pid` bigint(20) NOT NULL DEFAULT '0',
  `uid` int(11) NOT NULL,
  `content` text NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `reply` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jdi_comment`
-- -----------------------------
INSERT INTO `jdi_comment` VALUES ('66', 'member', '1', '0', '1', 'qweqwe', '0', '0', '0');
INSERT INTO `jdi_comment` VALUES ('67', 'tieba', '1', '0', '1', '123123', '0', '0', '123123');
INSERT INTO `jdi_comment` VALUES ('68', 'production', '2', '0', '1', '产品测试评论', '1425608162', '1425608162', '0');
INSERT INTO `jdi_comment` VALUES ('69', 'production', '2', '0', '1', '产品测试评论2', '1425608168', '1425608168', '0');
INSERT INTO `jdi_comment` VALUES ('70', 'production', '2', '0', '1', '产品测试评论3', '1425608171', '1425608171', '0');
INSERT INTO `jdi_comment` VALUES ('71', 'tiba', '2', '0', '1', '帖子测试评论3', '1425608299', '1425608299', '0');
INSERT INTO `jdi_comment` VALUES ('72', 'tiba', '2', '0', '1', '帖子测试评论4', '1425608304', '1425608304', '0');
INSERT INTO `jdi_comment` VALUES ('73', 'tiba', '2', '0', '1', '帖子测试评论4', '1425608393', '1425608393', '0');
INSERT INTO `jdi_comment` VALUES ('90', 'company', '3', '0', '1', 'a2', '1425631634', '1425631634', '0');
INSERT INTO `jdi_comment` VALUES ('76', 'tieba', '2', '0', '1', '帖子测试评论6', '1425608661', '1425608661', '0');
INSERT INTO `jdi_comment` VALUES ('87', 'company', '1', '0', '1', 'a1', '1425631578', '1425631578', '0');
INSERT INTO `jdi_comment` VALUES ('78', 'tieba', '2', '0', '1', '帖子测试评论6', '1425608732', '1425608732', '0');
INSERT INTO `jdi_comment` VALUES ('79', 'tieba', '2', '0', '1', '帖子测试评论6', '1425608733', '1425608733', '0');
INSERT INTO `jdi_comment` VALUES ('80', 'tieba', '2', '0', '1', '帖子测试评论6', '1425608734', '1425608734', '0');
INSERT INTO `jdi_comment` VALUES ('89', 'company', '3', '0', '1', 'a1', '1425631630', '1425631630', '0');
INSERT INTO `jdi_comment` VALUES ('82', 'tieba', '2', '0', '1', '帖子测试评论6', '1425608736', '1425608736', '0');
INSERT INTO `jdi_comment` VALUES ('88', 'company', '4', '0', '1', 'a1', '1425631612', '1425631612', '0');
INSERT INTO `jdi_comment` VALUES ('84', 'tieba', '2', '0', '1', '帖子测试评论6', '1425608738', '1425608738', '0');
INSERT INTO `jdi_comment` VALUES ('85', 'tieba', '2', '0', '1', '帖子测试评论6', '1425608739', '1425608739', '0');
INSERT INTO `jdi_comment` VALUES ('86', 'tieba', '2', '0', '1', '帖子测试评论6', '1425608740', '1425608740', '0');
INSERT INTO `jdi_comment` VALUES ('91', 'production', '19', '0', '44', 'ieieieieie', '1425720594', '1425720594', '0');
INSERT INTO `jdi_comment` VALUES ('92', 'production', '19', '0', '44', 'wdkdkdkdkdk', '1425720602', '1425720602', '0');
INSERT INTO `jdi_comment` VALUES ('93', 'production', '19', '0', '44', 'lelelellelel', '1425720609', '1425720609', '0');

-- -----------------------------
-- Table structure for `jdi_company`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_company`;
CREATE TABLE `jdi_company` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `picture` int(10) unsigned NOT NULL COMMENT '企业logo',
  `name` varchar(255) NOT NULL DEFAULT '0' COMMENT '企业全称',
  `telephone` varchar(255) NOT NULL COMMENT '联系电话',
  `uid` int(10) unsigned NOT NULL COMMENT '关联用户',
  `introduce` text NOT NULL,
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `category` char(50) NOT NULL COMMENT '类别',
  `point` char(80) NOT NULL COMMENT '坐标',
  `place` varchar(255) NOT NULL COMMENT '公司地址',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `jdi_company`
-- -----------------------------
INSERT INTO `jdi_company` VALUES ('3', '0', '时代科技', '2656360', '39', '时代科技\n                                                                                                            ', '1', '1', '', '', '0', '0');
INSERT INTO `jdi_company` VALUES ('7', '69', '文波公司', '221212', '44', '多萨达', '1', '0', '1.21,2.121', 'dasdasd', '1425701812', '1425701812');

-- -----------------------------
-- Table structure for `jdi_config`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_config`;
CREATE TABLE `jdi_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jdi_config`
-- -----------------------------
INSERT INTO `jdi_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1379235274', '1', '佰邦雪糕棒管理平台', '1');
INSERT INTO `jdi_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', '', '2');
INSERT INTO `jdi_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', '', '9');
INSERT INTO `jdi_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '6');
INSERT INTO `jdi_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '14');
INSERT INTO `jdi_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '', '15');
INSERT INTO `jdi_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐位', '2', '', '文档推荐位', '1379053380', '1419111436', '1', '1:列表页推荐\r\n2:频道页推荐\r\n3:网站首页推荐', '5');
INSERT INTO `jdi_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见性', '2', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1379235322', '1', '0:所有人可见\r\n1:仅注册会员可见\r\n2:仅管理员可见', '7');
INSERT INTO `jdi_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1422678418', '1', '1:基本\r\n2:内容\r\n3:用户\r\n4:系统\r\n5:安全\r\n', '16');
INSERT INTO `jdi_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '10');
INSERT INTO `jdi_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '11');
INSERT INTO `jdi_config` VALUES ('40', 'TEMP_PATH', '2', '前台模版路径', '2', '', '内容显示的模版路径', '1418650622', '1422414641', '1', './Template', '0');
INSERT INTO `jdi_config` VALUES ('24', 'DRAFT_AOTOSAVE_INTERVAL', '0', '自动保存草稿时间', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1386143323', '1', '60', '20');
INSERT INTO `jdi_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录数', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '10', '21');
INSERT INTO `jdi_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1421158169', '1', '1', '4');
INSERT INTO `jdi_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '17');
INSERT INTO `jdi_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '8');
INSERT INTO `jdi_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '18');
INSERT INTO `jdi_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '22');
INSERT INTO `jdi_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '24');
INSERT INTO `jdi_config` VALUES ('33', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '', '1386644047', '1425196939', '1', '1:index/index\r\n2:Index/verify\r\n3:file/upload\r\n4:file/download\r\n5:index/updatePassword\r\n6:index/updateNickname\r\n9:file/uploadpicture', '3');
INSERT INTO `jdi_config` VALUES ('41', 'SYSTEM_COLOR', '3', '颜色配置', '0', '', '通用颜色', '1418973661', '1418976664', '1', '#555\r\n#ac725e\r\n#d06b64\r\n#f83a22\r\n#fa573c\r\n#ff7537\r\n#ffad46\r\n#42d692\r\n#16a765\r\n#7bd148\r\n#b3dc6c\r\n#fbe983\r\n#fad165\r\n#92e1c0\r\n#9fe1e7\r\n#9fc6e7\r\n#4986e7\r\n#9a9cff\r\n#b99aff\r\n#c2c2c2\r\n#cabdbf\r\n#cca6ac\r\n#f691b2\r\n#cd74e6\r\n#a47ae2\r\n\r\n', '0');
INSERT INTO `jdi_config` VALUES ('34', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '', '仅超级管理员可访问的控制器方法', '1386644141', '1386644659', '1', '0:Addons/addhook\r\n1:Addons/edithook\r\n2:Addons/delhook\r\n3:Addons/updateHook\r\n4:Admin/getMenus\r\n5:Admin/recordList\r\n6:AuthManager/updateRules\r\n7:AuthManager/tree', '12');
INSERT INTO `jdi_config` VALUES ('35', 'REPLY_LIST_ROWS', '0', '回复列表每页条数', '2', '', '', '1386645376', '1387178083', '1', '10', '23');
INSERT INTO `jdi_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '25');
INSERT INTO `jdi_config` VALUES ('37', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '4', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '1', '13');
INSERT INTO `jdi_config` VALUES ('43', 'LINK_GROUP', '3', '链接分组', '2', '', '链接分组,t开头的分组代表只能是纯文本链接,\r\np开头的分组代表必须有图片,a开头的分组代表都行', '1419298534', '1421140065', '1', 'p-1:首页焦点图\r\np-2:二级焦点图', '0');
INSERT INTO `jdi_config` VALUES ('60', 'JDI_THEME', '1', '前台主题', '0', '', '', '1421898458', '1422414658', '1', 'default', '0');
INSERT INTO `jdi_config` VALUES ('61', 'WEB_URL', '1', '网站前台url', '1', '', '', '1422007394', '1422007407', '1', 'http://localhost/jdicms', '0');
INSERT INTO `jdi_config` VALUES ('62', 'MOBILE_THEME', '1', '手机模版', '0', '', '', '1422414699', '1422414699', '1', 'default', '0');
INSERT INTO `jdi_config` VALUES ('63', 'API_PRIVATE_KEY', '2', '接口访问密钥', '5', '', '', '1422678499', '1422841294', '1', '148731093hh56yhdthtg346h34hyebyn6n6w4xg3xhqh64j', '0');
INSERT INTO `jdi_config` VALUES ('69', 'API_OUT_TIME', '0', 'API请求超时时间', '5', '', '单位秒', '1423190005', '1423190171', '1', '8', '0');
INSERT INTO `jdi_config` VALUES ('70', 'COMPANY_CATEGORY', '3', '公司类别', '3', '', '', '1425522561', '1425522561', '1', '0:雪糕生产商\r\n1:雪糕棒生产商\r\n2:包装袋生产商', '0');
INSERT INTO `jdi_config` VALUES ('71', 'PRODUCTION_CATEGORY', '3', '产品类型', '3', '', '', '1425522649', '1425522649', '1', '0:雪糕\r\n1:雪糕棒\r\n2:包装袋\r\n3:包装箱', '0');

-- -----------------------------
-- Table structure for `jdi_download`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_download`;
CREATE TABLE `jdi_download` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `uid` int(10) unsigned NOT NULL COMMENT '发布用户id',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `link` varchar(255) NOT NULL COMMENT '外链',
  `deadline` int(10) NOT NULL COMMENT '截止时间',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览数量',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '更新时间',
  `url` varchar(255) NOT NULL COMMENT '内容页面url',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  `file` int(10) unsigned NOT NULL COMMENT '文件',
  `weight` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '权重',
  `is_up` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `jdi_download`
-- -----------------------------
INSERT INTO `jdi_download` VALUES ('1', '文件下载', '1', '9', '文件下载', '', '0', '3', '1422868705', '1422868705', '', '1', '13', '0', '0');
INSERT INTO `jdi_download` VALUES ('2', '下载文件', '1', '9', '下载文件', '', '0', '5', '1422869167', '1422869167', '', '1', '15', '0', '0');

-- -----------------------------
-- Table structure for `jdi_file`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_file`;
CREATE TABLE `jdi_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='文件表';

-- -----------------------------
-- Records of `jdi_file`
-- -----------------------------
INSERT INTO `jdi_file` VALUES ('15', '性能测试.doxc.doc', '54cf42acec957.doc', '2015-02-02/', 'doc', 'application/msword', '134144', '9e73d31b4fad35ecada6bda4ca87ef41', 'ba68d260f496c95fdbe402e73ee9457c6210ee01', '0', '1422869164');

-- -----------------------------
-- Table structure for `jdi_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_hooks`;
CREATE TABLE `jdi_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jdi_hooks`
-- -----------------------------
INSERT INTO `jdi_hooks` VALUES ('1', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '0', '', '1');
INSERT INTO `jdi_hooks` VALUES ('2', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '0', 'IPlistener', '1');
INSERT INTO `jdi_hooks` VALUES ('3', 'documentEditForm', '添加编辑表单的 扩展内容钩子', '1', '0', '', '1');
INSERT INTO `jdi_hooks` VALUES ('4', 'documentDetailAfter', '文档末尾显示', '1', '0', '', '1');
INSERT INTO `jdi_hooks` VALUES ('5', 'documentDetailBefore', '页面内容前显示用钩子', '1', '0', '', '1');
INSERT INTO `jdi_hooks` VALUES ('6', 'documentSaveComplete', '保存文档数据后的扩展钩子', '2', '0', '', '1');
INSERT INTO `jdi_hooks` VALUES ('7', 'documentEditFormContent', '添加编辑表单的内容显示钩子', '1', '0', '', '1');
INSERT INTO `jdi_hooks` VALUES ('8', 'adminArticleEdit', '后台内容编辑页编辑器', '1', '1378982734', '', '1');
INSERT INTO `jdi_hooks` VALUES ('13', 'AdminIndex', '首页小格子个性化显示', '1', '1422604050', 'SystemInfo', '1');
INSERT INTO `jdi_hooks` VALUES ('14', 'topicComment', '评论提交方式扩展钩子。', '1', '1380163518', '', '1');
INSERT INTO `jdi_hooks` VALUES ('16', 'app_begin', '应用开始', '2', '1384481614', '', '1');

-- -----------------------------
-- Table structure for `jdi_iplistener`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_iplistener`;
CREATE TABLE `jdi_iplistener` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(64) NOT NULL COMMENT 'ip地址',
  `visit_time` varchar(16) NOT NULL COMMENT '访问时间',
  `visit_url` varchar(256) NOT NULL COMMENT '访问地址',
  `city` varchar(32) NOT NULL COMMENT '地理位置',
  `isp` varchar(16) NOT NULL COMMENT '运营商',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jdi_iplistener`
-- -----------------------------
INSERT INTO `jdi_iplistener` VALUES ('1', '127.0.0.1', '1422867156', 'http://www.nb.com/jdicms/', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('2', '127.0.0.1', '1422867175', 'http://www.nb.com/jdicms/', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('3', '127.0.0.1', '1422867211', 'http://www.nb.com/jdicms/', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('4', '127.0.0.1', '1422867293', 'http://www.nb.com/jdicms/', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('5', '127.0.0.1', '1422867340', 'http://www.nb.com/jdicms/', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('6', '127.0.0.1', '1422867382', 'http://www.nb.com/jdicms/', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('7', '127.0.0.1', '1422867407', 'http://www.nb.com/jdicms/', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('8', '127.0.0.1', '1422867462', 'http://www.nb.com/jdicms/index/content/cate/sui/id/4.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('9', '127.0.0.1', '1422868712', 'http://www.nb.com/jdicms/index/content/cate/sui/id/4.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('10', '127.0.0.1', '1422868720', 'http://www.nb.com/jdicms/index/category/cate/xiazai/p/1.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('11', '127.0.0.1', '1422868737', 'http://www.nb.com/jdicms/index/category/cate/xiazai/p/1.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('12', '127.0.0.1', '1422869172', 'http://www.nb.com/jdicms/index/category/cate/xiazai/p/1.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('13', '127.0.0.1', '1422869252', 'http://www.nb.com/jdicms/index/category/cate/xiazai/p/1.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('14', '::1', '1422946682', 'http://localhost/jdicms/', '未知', '未知');
INSERT INTO `jdi_iplistener` VALUES ('15', '192.168.0.100', '1422948119', 'http://192.168.0.112/jdicms/', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('16', '127.0.0.1', '1423050893', 'http://www.nb.com/jdicms/', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('17', '192.168.1.119', '1423052891', 'http://192.168.1.108/', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('18', '192.168.1.119', '1423053010', 'http://192.168.1.108/JDICMS/', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('19', '192.168.1.119', '1423053022', 'http://192.168.1.108/JDICMS/', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('20', '127.0.0.1', '1423100214', 'http://www.nb.com/', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('21', '192.168.0.100', '1423100252', 'http://192.168.0.111/jdicms/', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('22', '127.0.0.1', '1423112843', 'http://www.nb.com/jdicms/index/content/cate/sui/id/4.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('23', '127.0.0.1', '1423112848', 'http://www.nb.com/jdicms/index/category/cate/xiazai/p/1.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('24', '127.0.0.1', '1423112849', 'http://www.nb.com/jdicms/index/category/cate/jiagou/p/1.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('25', '127.0.0.1', '1423112851', 'http://www.nb.com/jdicms/index/category/cate/sui/p/1.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('26', '127.0.0.1', '1423112855', 'http://www.nb.com/jdicms/index/category/cate/php/p/1.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('27', '127.0.0.1', '1423112858', 'http://www.nb.com/jdicms/index/content/cate/sui/id/2.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('28', '127.0.0.1', '1423112869', 'http://www.nb.com/jdicms/index/content/cate/sui/id/2.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('29', '127.0.0.1', '1423112876', 'http://www.nb.com/jdicms/index/category/cate/sui/p/1.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('30', '127.0.0.1', '1423112884', 'http://www.nb.com/jdicms/index/content/cate/sui/id/4.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('31', '127.0.0.1', '1423112889', 'http://www.nb.com/jdicms/index/category/cate/sui/p/1.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('32', '127.0.0.1', '1423112895', 'http://www.nb.com/jdicms/index/content/cate/sui/id/3.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('33', '127.0.0.1', '1423113003', 'http://www.nb.com/jdicms/index/content/cate/sui/id/3.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('34', '127.0.0.1', '1423113031', 'http://www.nb.com/jdicms/index/content/cate/sui/id/3.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('35', '127.0.0.1', '1423113058', 'http://www.nb.com/jdicms/index/content/cate/sui/id/3.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('36', '127.0.0.1', '1423113094', 'http://www.nb.com/jdicms/index/content/cate/sui/id/3.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('37', '127.0.0.1', '1423113119', 'http://www.nb.com/jdicms/index/content/cate/sui/id/3.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('38', '127.0.0.1', '1423113223', 'http://www.nb.com/jdicms/index/content/cate/sui/id/3.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('39', '127.0.0.1', '1423113355', 'http://www.nb.com/jdicms/index/content/cate/sui/id/3.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('40', '127.0.0.1', '1423113368', 'http://www.nb.com/jdicms/index/category/cate/xiazai/p/1.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('41', '127.0.0.1', '1423113370', 'http://www.nb.com/jdicms/index/category/cate/jiagou/p/1.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('42', '127.0.0.1', '1423113372', 'http://www.nb.com/jdicms/index/category/cate/php/p/1.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('43', '127.0.0.1', '1423113378', 'http://www.nb.com/jdicms/index/category/cate/wo/p/1.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('44', '127.0.0.1', '1423113384', 'http://www.nb.com/jdicms/index/index.html', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('45', '127.0.0.1', '1423189579', 'http://www.nb.com/jdicms/', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('46', '127.0.0.1', '1425037063', 'http://www.nb.com/', '未知', '未知');
INSERT INTO `jdi_iplistener` VALUES ('47', '127.0.0.1', '1425096836', 'http://www.nb.com/xuegaobang/', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('48', '127.0.0.1', '1425101783', 'http://www.nb.com/xuegaobang/', '未分配或者内网IP', '');
INSERT INTO `jdi_iplistener` VALUES ('49', '::1', '1425697115', 'http://localhost/xuegaobang/index.php', '未知', '未知');

-- -----------------------------
-- Table structure for `jdi_link`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_link`;
CREATE TABLE `jdi_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `picture_id` int(10) NOT NULL COMMENT '图片外键',
  `name` varchar(50) NOT NULL COMMENT '名称',
  `url` varchar(200) NOT NULL COMMENT 'url链接',
  `sort` int(11) NOT NULL COMMENT '排序',
  `group` varchar(20) NOT NULL DEFAULT '0',
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jdi_link`
-- -----------------------------
INSERT INTO `jdi_link` VALUES ('9', '78', '焦点二', '###', '0', 'p-1', '1');
INSERT INTO `jdi_link` VALUES ('2', '57', 'lihao ', '###', '0', 'p-2', '1');
INSERT INTO `jdi_link` VALUES ('6', '66', '巧克力', '###', '0', 'p-1', '1');
INSERT INTO `jdi_link` VALUES ('10', '79', '期望', '###', '0', 'p-1', '1');

-- -----------------------------
-- Table structure for `jdi_member`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_member`;
CREATE TABLE `jdi_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(40) NOT NULL COMMENT '密码',
  `mobile` char(15) NOT NULL COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态,-1代表删除,0代表禁用,1代表正常,2代表未审核,3代表审核未通过',
  `login_times` int(11) DEFAULT '0',
  `nickname` char(40) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0代表管理员,1代表运动员,2代表教练,3代表裁判',
  `score` mediumint(8) NOT NULL DEFAULT '0',
  `head` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `jdi_member`
-- -----------------------------
INSERT INTO `jdi_member` VALUES ('1', 'admin', '644bdda02dff64f25b94f5a656a9966578d3d0e9', '', '1425198625', '2130706433', '1425820716', '0', '1425198625', '1', '439', 'haomeaassss', '0', '0', '');
INSERT INTO `jdi_member` VALUES ('36', 'test', '0fdcd401563560514b51347603c8929761a87973', '', '1422515785', '0', '1422531841', '3232235633', '1422515785', '1', '9', 'test', '0', '0', '');
INSERT INTO `jdi_member` VALUES ('39', 'li1993ha0', '5c4551bc7063089af4580de7faf05f30d0ee857a', '', '1425115548', '2130706433', '1425189447', '2130706433', '1425115548', '1', '13', '时代科技', '1', '0', '');
INSERT INTO `jdi_member` VALUES ('40', 'gezhonglin', '644bdda02dff64f25b94f5a656a9966578d3d0e9', '', '1425256874', '2130706433', '1425256874', '2130706433', '1425256874', '-1', '1', 'tip', '1', '0', '');
INSERT INTO `jdi_member` VALUES ('44', 'wenbo', '644bdda02dff64f25b94f5a656a9966578d3d0e9', '', '1425701408', '3232235627', '1425713690', '3232235627', '1425701408', '1', '3', '文波', '1', '0', '52');

-- -----------------------------
-- Table structure for `jdi_menu`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_menu`;
CREATE TABLE `jdi_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  `module` char(20) NOT NULL DEFAULT 'Admin',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=297 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jdi_menu`
-- -----------------------------
INSERT INTO `jdi_menu` VALUES ('134', '新增', '128', '0', 'menu/add', '0', '新增菜单dasdasd', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('135', '删除', '128', '0', 'menu/del', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('136', '导入', '128', '0', 'menu/import', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('137', '编辑', '128', '0', 'menu/edit', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('141', '用户信息', '140', '0', 'user/index', '0', '', '用户管理', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('140', '用户', '0', '3', 'Public/index', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('142', '用户行为', '140', '0', 'user/action', '0', '', '行为管理', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('143', '权限管理', '140', '0', 'authManager/index', '0', '', '用户管理', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('144', '行为日志', '140', '0', 'action/actionlog', '0', '', '行为管理', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('145', '修改密码', '140', '0', 'user/updatePassword', '1', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('146', '修改昵称', '140', '0', 'user/updateNickname', '1', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('128', '菜单管理', '6', '6', 'menu/index', '0', '', '系统设置', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('129', '备份数据库', '6', '6', 'database/exportIndex', '0', '', '数据备份', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('130', '还原数据库', '6', '6', 'database/importIndex', '0', '', '数据备份', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('6', '系统', '0', '4', 'Public/index', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('148', '网站设置', '6', '0', 'config/group', '0', '', '系统设置', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('149', '配置管理', '6', '0', 'config/index', '0', '', '系统设置', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('150', '内容', '0', '2', 'Public/index', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('151', '分类管理', '150', '3', 'category/index', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('152', '模型管理', '6', '0', 'model/index', '0', '', '系统设置', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('153', '内容管理', '150', '1', 'content/index', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('166', '链接管理', '150', '2', 'link/index', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('265', '排序', '128', '0', 'menu/sort', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('266', '创建用户组', '143', '0', 'authManager/createGroup', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('267', '访问授权', '143', '0', 'authManager/access', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('268', '分类授权', '143', '0', 'authManager/category', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('188', '添加', '166', '0', 'link/add', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('189', '编辑', '166', '0', 'link/edit', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('190', '禁用', '166', '0', 'link/changeStatus\r', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('191', '删除', '166', '0', 'link/del\r', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('192', '排序', '166', '0', 'link/sort', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('193', '查看', '153', '0', 'content/news', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('194', '添加', '153', '0', 'content/add', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('195', '编辑', '153', '0', 'content/edit', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('196', '改变状态', '153', '0', 'content/changeStatus', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('197', '置顶', '153', '0', 'content/up', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('198', '删除', '153', '0', 'content/del', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('199', '添加', '151', '0', 'category/add\r', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('200', '编辑', '151', '0', 'category/edit\r', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('201', '禁用', '151', '0', 'category/changeStatus\r', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('202', '删除', '151', '0', 'category/delete\r', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('203', '排序', '151', '0', 'category/sort\r', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('204', '清除缓存', '151', '0', 'category/clearCache\r', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('205', '导入', '151', '0', 'category/import', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('252', '添加模型', '152', '0', 'model/add', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('253', '编辑模型', '152', '0', 'model/edit', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('254', '生成模型', '152', '0', 'model/generate', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('255', '添加属性', '152', '0', 'attribute/add', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('256', '编辑属性', '152', '0', 'attribute/edit', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('257', '属性管理', '152', '0', 'attribute/index', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('258', '配置管理', '149', '0', 'config/index', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('259', '新增配置', '149', '0', 'config/add', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('260', '编辑配置', '149', '0', 'config/edit', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('261', '批量保存', '149', '0', 'config/save', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('262', '删除配置', '149', '0', 'config/del', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('263', '分组管理', '149', '0', 'config/group', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('264', '排序', '149', '0', 'config/sort', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('269', '扩展', '0', '5', 'public/index', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('270', '插件管理', '269', '0', 'addons/index', '0', '', '扩展', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('271', '钩子管理', '269', '0', 'addons/hooks', '0', '', '扩展', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('272', '创建', '270', '0', 'addons/create', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('273', '预览', '270', '0', 'addons/preview', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('274', '设置', '270', '0', 'addons/config', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('275', '编辑钩子', '271', '0', 'addons/edithook', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('276', '添加钩子', '271', '0', 'addons/addhook', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('277', '插件', '0', '6', 'addonsBack/adminList', '0', '', '', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('278', '编辑模版', '6', '0', 'temp/editTemp', '0', '', '模版管理', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('279', '模版设置', '6', '0', 'temp/index', '0', '', '模版管理', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('280', '模块管理', '269', '0', 'module/index', '0', '', '扩展', '0', 'Admin');
INSERT INTO `jdi_menu` VALUES ('290', '企业中心', '0', '0', 'dispatch/execute_module?_module=Person&_controller=index&_action=index', '0', '', '', '0', 'Person');
INSERT INTO `jdi_menu` VALUES ('296', '佰帮', '0', '0', 'dispatch/execute_module?_module=BaiBang&_controller=Production&_action=index', '0', '', '', '0', 'BaiBang');

-- -----------------------------
-- Table structure for `jdi_model`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_model`;
CREATE TABLE `jdi_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `field_sort` text COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text COMMENT '属性列表（表的字段）',
  `attribute_alias` varchar(255) NOT NULL DEFAULT '' COMMENT '属性别名定义',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `type` tinyint(3) unsigned NOT NULL,
  `engine_type` varchar(25) NOT NULL DEFAULT 'MyISAM' COMMENT '数据库引擎',
  `pid` int(10) NOT NULL COMMENT '父id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `jdi_model`
-- -----------------------------
INSERT INTO `jdi_model` VALUES ('22', 'download', '下载', '{\"1\":[\"122\",\"125\",\"133\"],\"2\":[\"129\",\"127\",\"237\",\"126\",\"128\"]}', '1:基础;2:扩展', '', 'title:标题\r\nview:浏览数量\r\ncreate_time:创建时间\r\nupdate_time:更新时间\r\ndeadline:截至日期\r\nlink:外链\r\n', 'lists', 'add', 'edit', 'title:标题\r\nview:浏览数量\r\ncreate_time:创建时间\r\nupdate_time:更新时间\r\ndeadline:截至日期\r\nlink:外链', '10', 'title', '', '1418978727', '1421066281', '1', '0', 'MyISAM', '0');
INSERT INTO `jdi_model` VALUES ('18', 'base_article', '基础文档', '{\"1\":[\"82\",\"85\"],\"2\":[\"88\",\"89\",\"87\",\"236\",\"86\"]}', '1:基础;2:扩展', '', 'title:标题\r\nview:浏览数量\r\ncreate_time:创建时间\r\nupdate_time:更新时间\r\ndeadline:截至日期\r\nlink:外链\r\n', 'lists', 'add', 'edit', 'title:标题\r\nview:浏览数量\r\ncreate_time:创建时间\r\nupdate_time:更新时间\r\ndeadline:截至日期\r\nlink:外链', '10', 'title', '', '1418802016', '1421066327', '1', '0', 'MyISAM', '0');
INSERT INTO `jdi_model` VALUES ('20', 'article', '文章', '{\"1\":[\"93\",\"106\"],\"2\":[\"239\",\"134\",\"96\",\"238\"],\"3\":[\"108\",\"107\",\"100\",\"98\",\"235\",\"104\",\"105\",\"97\",\"99\"]}', '1:基础;2:扩展;3:其他', '', 'title:标题\r\nview:浏览数量\r\ncreate_time:创建时间\r\nupdate_time:更新时间\r\ndeadline:截至日期\r\nlink:外链\r\n', 'lists', 'add', 'edit', 'title:标题\r\nview:浏览数量\r\ncreate_time:创建时间\r\nupdate_time:更新时间\r\ndeadline:截至日期\r\nlink:外链', '10', 'title', '', '1418954565', '1421134006', '1', '0', 'MyISAM', '0');
INSERT INTO `jdi_model` VALUES ('32', 'article_picture', '图片模型', '{\"1\":[\"248\",\"245\",\"251\"],\"2\":[\"253\",\"249\",\"243\",\"252\",\"244\",\"242\",\"254\",\"255\"]}', '1:基础;2:扩展', '', 'title:标题\r\nview:浏览数量\r\ncreate_time:创建时间\r\nupdate_time:更新时间\r\ndeadline:截至日期\r\nlink:外链\r\n', 'lists', 'add', 'edit', 'title:标题\r\nview:浏览数量\r\ncreate_time:创建时间\r\nupdate_time:更新时间\r\ndeadline:截至日期\r\nlink:外链', '10', 'title', '', '1421632257', '1421662503', '1', '0', 'MyISAM', '0');
INSERT INTO `jdi_model` VALUES ('33', 'production', '产品模型', '', '1:基础', '', '', '', '', '', '', '10', '', '', '1425109140', '1425109140', '1', '0', 'MyISAM', '0');
INSERT INTO `jdi_model` VALUES ('34', 'company', '企业资料', '', '1:基础', '', '', '', '', '', '', '10', '', '', '1425109845', '1425109845', '1', '1', 'MyISAM', '0');
INSERT INTO `jdi_model` VALUES ('37', 'tieba', '贴吧', '{\"1\":[\"276\",\"277\"]}', '1:基础', '', '', '', '', '', '1:名称', '10', '', '', '1425353078', '1425371307', '1', '1', 'MyISAM', '0');

-- -----------------------------
-- Table structure for `jdi_module`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_module`;
CREATE TABLE `jdi_module` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `jdi_module`
-- -----------------------------
INSERT INTO `jdi_module` VALUES ('33', 'Person', '企业中心', '企业用户的个人中心', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"2\",\"display\":\"1\"}', 'tp', '0.1', '1425108835');
INSERT INTO `jdi_module` VALUES ('39', 'BaiBang', '佰帮', '雪糕棒管理模块', '1', 'null', 'tp', '0.1', '1425820958');

-- -----------------------------
-- Table structure for `jdi_node`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_node`;
CREATE TABLE `jdi_node` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) unsigned NOT NULL COMMENT '1是栏目,2是单页面,3是外部链接',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '栏目名称',
  `symbol` varchar(100) NOT NULL DEFAULT '' COMMENT '栏目英文名称',
  `pid` int(11) NOT NULL COMMENT '父级栏目',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序字段',
  `model_id` int(11) NOT NULL DEFAULT '0' COMMENT '模型',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_user` int(11) NOT NULL DEFAULT '0' COMMENT '创建者',
  `temp_category` char(40) NOT NULL DEFAULT '' COMMENT '栏目页模版',
  `temp_list` char(40) NOT NULL DEFAULT '' COMMENT '列表页模版',
  `temp_content` char(40) NOT NULL DEFAULT '' COMMENT '内容页模版',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '要跳转的url',
  `list_num` int(11) NOT NULL COMMENT '每页显示的记录数量',
  `index_show` tinyint(1) DEFAULT '1' COMMENT '是否在主页显示',
  `status` tinyint(1) DEFAULT '0' COMMENT '-1代表以删除,0代表禁用,1代表正常',
  `verify` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否需要审核',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jdi_node`
-- -----------------------------
INSERT INTO `jdi_node` VALUES ('3', '2', '关于我们', 'wo', '0', '3', '20', '1422006329', '1422006329', '0', 'category.html', 'list.html', 'content.html', '', '10', '1', '1', '0');
INSERT INTO `jdi_node` VALUES ('4', '1', '案例展示', 'sui', '0', '1', '20', '1422006329', '1422006329', '0', 'category.html', 'list.html', 'content.html', '', '10', '1', '1', '0');
INSERT INTO `jdi_node` VALUES ('6', '1', '人才招聘', 'php', '0', '2', '20', '1422006329', '1422006329', '0', 'category.html', 'list.html', 'content.html', '', '10', '1', '1', '0');
INSERT INTO `jdi_node` VALUES ('7', '1', '新闻中心', 'jiagou', '0', '0', '20', '1422006329', '1422006329', '0', 'category.html', 'list.html', 'content.html', '', '10', '1', '1', '0');
INSERT INTO `jdi_node` VALUES ('9', '1', '下载中心', 'xiazai', '0', '0', '22', '1422867735', '1422867735', '0', 'category.html', 'list.html', 'content.html', '', '10', '1', '1', '0');

-- -----------------------------
-- Table structure for `jdi_notice`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_notice`;
CREATE TABLE `jdi_notice` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `detail` text NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jdi_notice`
-- -----------------------------
INSERT INTO `jdi_notice` VALUES ('1', '1', '-1', '玩儿', '0', '0', '沙发');
INSERT INTO `jdi_notice` VALUES ('2', '1', '-1', '不通过', '1425621918', '1425621918', '您的企业资料未通过审核,原因见详情');
INSERT INTO `jdi_notice` VALUES ('3', '1', '-1', 'haode', '1425622435', '1425622435', '您的企业资料未通过审核,原因见详情');
INSERT INTO `jdi_notice` VALUES ('4', '1', '-1', '萨达', '1425622575', '1425622575', '您的企业资料未通过审核,原因见详情');
INSERT INTO `jdi_notice` VALUES ('5', '1', '0', '几点回家', '1425624965', '1425624965', '您的企业资料未通过审核,原因见详情');

-- -----------------------------
-- Table structure for `jdi_picture`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_picture`;
CREATE TABLE `jdi_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=84 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jdi_picture`
-- -----------------------------
INSERT INTO `jdi_picture` VALUES ('1', '/Uploads/Picture/2014-11-13/54642c43484a9.jpg', '', '71dc21797cfb7dca66515adcc4abe93b', 'f96f72d919ce79498f8608a647e5ab534c12c9ab', '1', '1415851075');
INSERT INTO `jdi_picture` VALUES ('2', '/Uploads/Picture/2014-11-20/546dc0c7c7ef4.png', '', 'd8438e506d466ed38ee6b9dc4a232b40', 'b1191b0a06d36f92bb9fb21bc94daaab80265f03', '1', '1416478919');
INSERT INTO `jdi_picture` VALUES ('3', '/Uploads/Picture/2014-11-21/546ec9e8d24ec.png', '', '5d1d5d4195258797a0b6fcffadcd8511', '5e6d0c581d800dd0622a76f091b2701456f8e351', '1', '1416546792');
INSERT INTO `jdi_picture` VALUES ('4', '/Uploads/Picture/2014-11-21/546ed0ddc3cba.png', '', '3c838b9f71bc517a3b8028415bb59cb1', '09ac100f01411da86664b69250aba8f0b83d1491', '1', '1416548573');
INSERT INTO `jdi_picture` VALUES ('5', '/Uploads/Picture/2014-11-21/546edffc7d2a6.png', '', '2f2493b43169047408921c245572d250', 'b108c0a832627b36e047a473231221e9d58619a2', '1', '1416552444');
INSERT INTO `jdi_picture` VALUES ('6', '/Uploads/Picture/2014-11-21/546ee04d260c2.png', '', '333e3d1dd2ca98d7e989131b7d9a338f', '45e103b823372a5a033d9d317008c7ed218752f9', '1', '1416552525');
INSERT INTO `jdi_picture` VALUES ('7', '/Uploads/Picture/2014-11-21/546ee16ca61b1.png', '', '2791e727022d2d863e17a02e57c8237f', 'eb067c0e3dbe17297247c7307b956daab3ea0bad', '1', '1416552812');
INSERT INTO `jdi_picture` VALUES ('8', '/Uploads/Picture/2014-11-21/546ee1c64539c.png', '', 'f9d7f9a78cc852a599bc301cda134145', 'ef2502b45938da6de9c7321b428737eb4d9a3884', '1', '1416552902');
INSERT INTO `jdi_picture` VALUES ('9', '/Uploads/picture/2014-12-19/5493ea16ba73f.png', '', '1f990d9695bf79fe5fdcd0f0840f01b7', '18abc3278d6bc1bee0af5ba2272d99b19f5554f5', '1', '1418979862');
INSERT INTO `jdi_picture` VALUES ('10', '/Uploads/picture/2014-12-19/5493ea229e330.png', '', 'f321e4d05f11c423b4c76fa0730d90bc', '7d8471d49aae560c4c90986f3cef78719f1c5e59', '1', '1418979874');
INSERT INTO `jdi_picture` VALUES ('11', '/Uploads/picture/2014-12-20/549550c3cf9fc.png', '', '780281674310278a3d6a3956aa3beb2f', 'e04954ee182439a53d4b751577abdc1749463d72', '1', '1419071683');
INSERT INTO `jdi_picture` VALUES ('12', '/Uploads/picture/2014-12-21/5495eb082a0b8.png', '', '4cacbb3d8c186b4092c625b6337b83b1', '0c4383749ef8ae4fa4c68374939c14efb707e525', '1', '1419111176');
INSERT INTO `jdi_picture` VALUES ('13', '/Uploads/picture/2014-12-22/5497ef6776144.jpg', '', 'cc26a9e19822e00bf5dade2423f98a1f', '98d8c84d6c849632d2e678eed3c9c1a857ed52f9', '1', '1419243367');
INSERT INTO `jdi_picture` VALUES ('14', '/Uploads/picture/2014-12-25/549c20281f270.jpg', '', '84672df6d0e467a72564cfd0a4d2e32b', '9683a7d74dc9bd74c40c6d86890cccb83822c3d9', '1', '1419517992');
INSERT INTO `jdi_picture` VALUES ('15', '/Uploads/picture/2014-12-27/549e71dcc1c01.jpg', '', '907e4a686127af79a7833d2dee568118', '704d6be61ee914e2a01fb91d694a95b4ffdf63c1', '1', '1419669980');
INSERT INTO `jdi_picture` VALUES ('16', '/Uploads/picture/2014-12-27/549e71e46d603.jpg', '', 'f87e138aec148c5b260d38705dcd1f5a', 'bbeeb497bd5c0f8a490cd7f55a3ab1019a71cb34', '1', '1419669988');
INSERT INTO `jdi_picture` VALUES ('17', '/Uploads/picture/2014-12-27/549e74799ef25.jpg', '', '0fb4348fd1b792903cfa9b9e7c5706ab', '58acb5a6adae9c0e208da697de6d268802cb1a33', '1', '1419670649');
INSERT INTO `jdi_picture` VALUES ('18', '/Uploads/picture/2014-12-27/549e77c53d74c.jpg', '', '8721fc6c1a94e5c33aad61983e03847d', 'b8e9d43000caddd41b9400d9190ebdd7cdc0f720', '1', '1419671493');
INSERT INTO `jdi_picture` VALUES ('19', '/Uploads/picture/2014-12-27/549e78c9df6d5.jpg', '', '500c06dcc1ec4b4be08edea35f1b185b', 'f2b07bbd919763aca6c99031684342a5934d5890', '1', '1419671753');
INSERT INTO `jdi_picture` VALUES ('20', '/Uploads/picture/2014-12-27/549e799756fbe.jpg', '', '17735a9573e7f839c35bf187972cbf04', 'e1cfc45e5d314d7c5093273aa56e8bc9239c45e7', '1', '1419671959');
INSERT INTO `jdi_picture` VALUES ('21', '/Uploads/picture/2014-12-27/549e7ada2b54d.jpg', '', 'bbc99dc973eb6631f269858d1929ca69', '0008d143a47164eb1e72997434ea3106cb6cb824', '1', '1419672276');
INSERT INTO `jdi_picture` VALUES ('22', '/Uploads/picture/2014-12-27/549e7bf07ce95.jpg', '', '0145cee52cbda8b3b756669358872c37', 'f7c434b1786b2baec5be33d1aa19c141ce0cffa1', '1', '1419672560');
INSERT INTO `jdi_picture` VALUES ('23', '/Uploads/picture/2014-12-29/54a0b7038c685.jpg', '', 'ed9d57f48a5f9e8d3ec4a67746c3e8bf', '40c70a77c4e42a28443bf057df2c8ee8ced23bb1', '1', '1419818755');
INSERT INTO `jdi_picture` VALUES ('24', '/Uploads/picture/2014-12-29/54a0ba0fc3f61.jpg', '', 'be6192e2556ad8eac853feb88cfcd12b', '996e59c3dfdf511568dc76e88d8851fe95d98912', '1', '1419819535');
INSERT INTO `jdi_picture` VALUES ('25', '/Uploads/picture/2014-12-31/54a36f62c9af6.jpg', '', 'a55d63bf2084090fbc1a944f835d3bca', 'c492f20815d7b66832f9166225e33288a662d65c', '1', '1419997026');
INSERT INTO `jdi_picture` VALUES ('26', '/Uploads/picture/2014-12-31/54a3858f1db10.jpg', '', 'da1b29b1c904da4d009b4bcb8f8d30ac', '070050538b0daa96f59af7d5b0434940fab1ced4', '1', '1420002703');
INSERT INTO `jdi_picture` VALUES ('27', '/Uploads/picture/2014-12-31/54a3a50c733c5.jpg', '', 'acc9d12f04e4e9fddb61c74fbfa6c7ef', '851554e25a426d7fa71ef0d8dfa2ef6d394cb1db', '1', '1420010764');
INSERT INTO `jdi_picture` VALUES ('28', '/Uploads/picture/2015-01-05/54aa3eaed359f.png', '', '983f3be2ed0eaf9c5c979ad53e159b0f', '09ae19b2a9e3020f562edc8a96d9562d4a8b086f', '1', '1420443310');
INSERT INTO `jdi_picture` VALUES ('57', '/Uploads/picture/2015-03-06/54f94a0163e80.gif', '', 'ff3d9c4cfa363bbf9405ed222281d1f6', '91a856e0f2a43f167e03686d177dc2b9ea8526cc', '1', '1425623553');
INSERT INTO `jdi_picture` VALUES ('52', '/Uploads/picture/2015-02-28/54f19036408f4.gif', '', '0ed7a856091c60842c705acdbe4cbd62', 'eda763bf4388b8ca4f5c0cb178658315ba8d1a2d', '1', '1425117238');
INSERT INTO `jdi_picture` VALUES ('54', '/Uploads/picture/2015-03-01/54f2a8cd76c0b.gif', '', '37239c2b1ba2831f3b13f36628e80557', '75dc0150edef877869a164e63bd8805daf7051d2', '1', '1425189069');
INSERT INTO `jdi_picture` VALUES ('32', '/Uploads/picture/2015-01-06/54ab3fb99f91f.png', '', 'eebae605140f25e19798fad0ed7c6779', '50a9f02b1473f7540816e22fbe64a6a7d8edbd6b', '1', '1420509113');
INSERT INTO `jdi_picture` VALUES ('33', '/Uploads/picture/2015-01-06/54ab400ad84fd.png', '', '4e7a9fae02eec00d3cd09300160557ee', '6e638d3ef61bc177a6e645a96a36f2184b5199e7', '1', '1420509194');
INSERT INTO `jdi_picture` VALUES ('34', '/Uploads/picture/2015-01-06/54ab4462eaf05.jpg', '', '8283c08e2413c82268777e632e2063f7', 'b36b4d0198f86766c1b3c36f6b51790b7d8819ee', '1', '1420510306');
INSERT INTO `jdi_picture` VALUES ('35', '/Uploads/picture/2015-01-06/54ab4474c6c67.jpg', '', '47d8eed24baafab78fd4e7e2ef42eaf4', 'c3239f7933186a7fc10e00f4c8f0a12f4157d277', '1', '1420510324');
INSERT INTO `jdi_picture` VALUES ('36', '/Uploads/picture/2015-01-06/54ab448ea0a03.jpg', '', '69f8b9b88891dc1196c387fff45616d1', '5871b15e0f9ad6b2b8469eb5ad34047b7466e5f3', '1', '1420510350');
INSERT INTO `jdi_picture` VALUES ('37', '/Uploads/picture/2015-01-06/54ab449d91482.jpg', '', '6dc8c4dc681b058f549c7ddcadb069c3', 'b02d0b26018a4af98347346bc98d16bb352a51cd', '1', '1420510365');
INSERT INTO `jdi_picture` VALUES ('38', '/Uploads/picture/2015-01-06/54ab44adc8dbb.jpg', '', '629022e20a40ca1af7b29eee316a0efb', '33b6db2d162fa4ca9ab041bf798355aad97c8f98', '1', '1420510381');
INSERT INTO `jdi_picture` VALUES ('39', '/Uploads/picture/2015-01-06/54ab44bfc0202.jpg', '', '05e47a69fc23a62b99918fb853264057', 'dd8c1b53803993a5d029e18c55ad4a8025bbb04a', '1', '1420510399');
INSERT INTO `jdi_picture` VALUES ('40', '/Uploads/picture/2015-01-09/54af7cc6ed63b.jpg', '', 'd75cb2655b38383b87984a63b852f0cf', 'e70c3b22f591945d1db125f4f974846a1a03a19d', '1', '1420786886');
INSERT INTO `jdi_picture` VALUES ('41', '/Uploads/picture/2015-01-09/54af7cd09cea6.jpg', '', 'b63a4635a4853f02013e19e684220f31', '7f91c71c614678b21846721a91b40a6eca97dd67', '1', '1420786896');
INSERT INTO `jdi_picture` VALUES ('42', '/Uploads/picture/2015-01-09/54af7ddbd944a.gif', '', '619382435048a8e7fd7711382b6d4226', '2050ea55da96242ebb82615d01cc2dddea88e877', '1', '1420787163');
INSERT INTO `jdi_picture` VALUES ('43', '/Uploads/picture/2015-01-09/54af7e08391c9.gif', '', 'b9c6fc79bea2d3e2284a8edcdecd5f63', 'be11f542318778fe091da66dcf718fe22507a66d', '1', '1420787208');
INSERT INTO `jdi_picture` VALUES ('44', '/Uploads/picture/2015-01-22/54c05f079a491.png', '', '1e77cbbb3e124986bc1f22c7285b062c', '64ad9a387b6f5676aa9f9dc2268e6df2ba723dfb', '1', '1421893383');
INSERT INTO `jdi_picture` VALUES ('45', '/Uploads/picture/2015-01-22/54c05f07b3a44.png', '', 'd8439ca6aab2ebab7f92fbb8ad268c63', '5b975c633ba5031014c10dbee8d7c4c1cd47fd33', '1', '1421893383');
INSERT INTO `jdi_picture` VALUES ('46', '/Uploads/picture/2015-01-22/54c05f084780d.png', '', '4c432738f2fef85167892264cbe1d12e', 'de6d9a04b3d0d765cf9f5c4ac2ae07f07c5218ea', '1', '1421893384');
INSERT INTO `jdi_picture` VALUES ('47', '/Uploads/picture/2015-01-22/54c05f08bd359.png', '', '8650d4d80da6667907a462fecae3d57a', '9feec21835bb328db27dcfe81f179b07f8d9a824', '1', '1421893384');
INSERT INTO `jdi_picture` VALUES ('48', '/Uploads/picture/2015-01-22/54c05f0944574.png', '', '9d484768d6956431930e6ab04b32d38e', '4567d4be6d84034d2211ca688acb94affeae68f6', '1', '1421893385');
INSERT INTO `jdi_picture` VALUES ('49', '/Uploads/picture/2015-01-22/54c05f09c0a62.png', '', '02d04e13a4b80ce5bc0a3c6ff889544d', 'adae9168e09cb9526d892ec999c239cec064b775', '1', '1421893385');
INSERT INTO `jdi_picture` VALUES ('50', '/Uploads/picture/2015-01-22/54c05f0a612c9.png', '', '9e9193ed9041944621dd69e6fad8751d', 'c7412dbdcf5a3fb29a91fc1b1bc8a1839be2cae8', '1', '1421893386');
INSERT INTO `jdi_picture` VALUES ('51', '/Uploads/picture/2015-01-22/54c05f0adf313.png', '', 'cfe9d80046fd8468153e4bf2ce4a0b34', '5c73c2289612560c7c738bc06834a4c8abf201b5', '1', '1421893386');
INSERT INTO `jdi_picture` VALUES ('53', '/Uploads/picture/2015-02-28/54f1919038707.jpg', '', '87086c82c12c87785778d7ee8cb23f14', '92fed0a78fa20c9981c47c41607537bb732a2d68', '1', '1425117584');
INSERT INTO `jdi_picture` VALUES ('55', '/Uploads/picture/2015-03-02/54f3b7ead2583.jpg', '', '611de4d31de6898c01618b5511f9c8ae', 'bede8b613eb2d82fbef81f60da41d9c5200574eb', '1', '1425258474');
INSERT INTO `jdi_picture` VALUES ('56', '/Uploads/picture/2015-03-05/54f82519c7605.png', '', '2c3aa7a3ab1c2eedc3b0f5f2363bf68a', '1820b5a3bf639212397609ea1e856937d13c2e55', '1', '1425548569');
INSERT INTO `jdi_picture` VALUES ('58', '/Uploads/picture/2015-03-06/54f97b68225dc.jpg', '', '996642c79722267f61c9517c7b352ee0', 'a8e293c94de4ee96a6bc8e9e65886679e339e844', '1', '1425636199');
INSERT INTO `jdi_picture` VALUES ('59', '/Uploads/picture/2015-03-07/54fa51a9b55ba.jpg', '', '4a8aa3396a8e2f7a1415e1810105489d', 'cf5a9ea13bf7c1beb6efff5b254f53c359e32d7e', '1', '1425691049');
INSERT INTO `jdi_picture` VALUES ('60', '/Uploads/picture/2015-03-07/54fa51d247d11.jpg', '', 'c654a3c782571e66b88ae3f7d00b7eca', 'd4cb7684254fc056c36221535068f2763dc11525', '1', '1425691090');
INSERT INTO `jdi_picture` VALUES ('61', '/Uploads/picture/2015-03-07/54fa51f964aef.jpg', '', 'f81d268656584f5f3289c24894acb102', 'd188fd09e60edf337100738014ff3aa5b4689ce3', '1', '1425691129');
INSERT INTO `jdi_picture` VALUES ('62', '/Uploads/picture/2015-03-07/54fa53644eefa.jpg', '', '6f938d0e58b42eea5c409414d8a77a6f', '7176f4d3788c2d1375cc7c971b8c543460126f2b', '1', '1425691491');
INSERT INTO `jdi_picture` VALUES ('63', '/Uploads/picture/2015-03-07/54fa5398e7c56.jpg', '', '48da0da3454f897ad51364d253d6d329', 'aa135e2ea658d322104ce783e20af4d4012c1d46', '1', '1425691544');
INSERT INTO `jdi_picture` VALUES ('64', '/Uploads/picture/2015-03-07/54fa563796197.jpg', '', 'cf02d9d017e8e88f6e9a5a4e4a2084ac', '071c48b4ecba490dfe3829cb475b7d1d978c6e4f', '1', '1425691965');
INSERT INTO `jdi_picture` VALUES ('65', '/Uploads/picture/2015-03-07/54fa566917eae.jpg', '', 'c099fa20584ad0e8a94f46705a1d4459', '807114bc1345cb84ef72494c91fbe76d31310a9f', '1', '1425691996');
INSERT INTO `jdi_picture` VALUES ('66', '/Uploads/picture/2015-03-07/54fa5671c33d5.jpg', '', 'ca800a2ca7354f321f3a079786f1d239', 'cf11471c788e3e38ffcf7935718e4a4852fa70de', '1', '1425692273');
INSERT INTO `jdi_picture` VALUES ('67', '/Uploads/picture/2015-03-07/54fa7a2bda853.jpg', '', '6cb50771b5b8bf3174f780192a7aef46', '8ebe0f4d7c47936c6e7113fc3cc51db24cb98288', '1', '1425701419');
INSERT INTO `jdi_picture` VALUES ('68', '/Uploads/picture/2015-03-07/54fa7aba37bfb.jpg', '', 'a3b245b0a9229ea889cef52e71fc94f5', '728fb236bd9fd96320d5bc1ca6805b4ec4dc79f4', '1', '1425701562');
INSERT INTO `jdi_picture` VALUES ('69', '/Uploads/picture/2015-03-07/54fa7ba3aad73.jpg', '', '50bc3f3bd886fc7122db9b71f596afa5', '7a3dbba70bbf08b4d07898d4219618d9b653ccaa', '1', '1425701795');
INSERT INTO `jdi_picture` VALUES ('70', '/Uploads/picture/2015-03-07/54fa7be983160.jpg', '', 'c45cfec69d1644b126a025c9a602567e', '7057e61ace0cb9261139730d1c9600c016d4aa96', '1', '1425701865');
INSERT INTO `jdi_picture` VALUES ('71', '/Uploads/picture/2015-03-07/54fa98d0ba472.png', '', 'c5bdb16c8d352e5bec360fbd11f09c39', '8baf6166aa33b249b8f6f750e43e3f0f5c8c1fb0', '1', '1425709264');
INSERT INTO `jdi_picture` VALUES ('72', '/Uploads/picture/2015-03-07/54fa9a5e69297.jpg', '', '23df9b32d2f722bcb92e6043ca091559', '2c2e34f8763f935bf3e4e07074a9a457ce86aa8a', '1', '1425709660');
INSERT INTO `jdi_picture` VALUES ('73', '/Uploads/picture/2015-03-07/54fa9a6ae71af.jpg', '', 'a67961bf487a82421c1705c96caa72db', 'e797392bbbaa15cf9573b1ea457f2591fba6ec1c', '1', '1425709672');
INSERT INTO `jdi_picture` VALUES ('74', '/Uploads/picture/2015-03-07/54fa9a8451bed.jpg', '', '8f2817b986487a1724887649826d7f85', '6159681da9c5e2137f164b4937a1e46270992e6c', '1', '1425709700');
INSERT INTO `jdi_picture` VALUES ('75', '/Uploads/picture/2015-03-07/54fa9bc0d1957.jpg', '', '2fb78ed4e7a545952b009816ebcb41da', '2d37952990ebb6080e60a9c225066432be23862d', '1', '1425709980');
INSERT INTO `jdi_picture` VALUES ('76', '/Uploads/picture/2015-03-07/54fa9bc3e731d.jpg', '', '3c7cfe2b1efe72816f11d2e0b0537cee', '4cfd680bdc7439d3766b1882aa80b2211ab0005d', '1', '1425710016');
INSERT INTO `jdi_picture` VALUES ('77', '/Uploads/picture/2015-03-07/54fa9c878d957.jpg', '', '3e3ded7f95f9c9ffe9d96a4d55fc3916', '182b7dade24f38109c12bdeee58b2016ee37819f', '1', '1425710210');
INSERT INTO `jdi_picture` VALUES ('78', '/Uploads/picture/2015-03-07/54faaa946f82f.png', '', 'c19acb8ea45d8617cc4e0af39d2b5100', '64f647ef4054aaa1da41000b7c8c1df925b933a4', '1', '1425713812');
INSERT INTO `jdi_picture` VALUES ('79', '/Uploads/picture/2015-03-07/54faaaa1eab69.png', '', '014d3b146969fca05425cfdcda7f9a61', 'eed58adc5ca9f14b362872e8dd967d13546edccb', '1', '1425713825');
INSERT INTO `jdi_picture` VALUES ('80', '/Uploads/picture/2015-03-07/54faaba332ceb.jpg', '', '3a10ac1c86cc5a0c7b57766eb6410c24', '75ec2921b1ae1844566655e20321185af8b242f2', '1', '1425714083');
INSERT INTO `jdi_picture` VALUES ('81', '/Uploads/picture/2015-03-07/54faabd06dff0.jpg', '', '01d10421304452ad75adddeb499f9e3b', '375e93b4a474dabf1df1110654b87a57e7900c91', '1', '1425714128');
INSERT INTO `jdi_picture` VALUES ('82', '/Uploads/picture/2015-03-07/54faac96d4516.jpg', '', 'bef1e381376677cc72103385250a9577', '86a0376e01b4b946daa45d8e5f174ce6b270e782', '1', '1425714326');
INSERT INTO `jdi_picture` VALUES ('83', '/Uploads/picture/2015-03-07/54faacd4cb194.jpg', '', 'c2e4c67c634cb497991fd8a25bdb0b5a', '1d43d4f222785189e4e63c64d2a6a8c3b203a18c', '1', '1425714388');

-- -----------------------------
-- Table structure for `jdi_production`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_production`;
CREATE TABLE `jdi_production` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '产品发布者',
  `name` varchar(100) NOT NULL COMMENT '产品名称',
  `company` varchar(50) NOT NULL COMMENT '公司名称',
  `introduce` text NOT NULL COMMENT '产品介绍',
  `picture` int(10) unsigned NOT NULL COMMENT '产品封面',
  `create_time` int(10) NOT NULL COMMENT '创建时间',
  `update_time` int(10) NOT NULL COMMENT '更新时间',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态',
  `category` char(50) NOT NULL COMMENT '产品类型',
  `burdening` varchar(255) NOT NULL COMMENT '配料',
  `recommend` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否推荐',
  `is_top` tinyint(1) unsigned NOT NULL COMMENT '置顶',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `jdi_production`
-- -----------------------------
INSERT INTO `jdi_production` VALUES ('7', '44', 'sdasdad', '文波公司', 'asdad', '70', '1425701868', '1425701868', '1', '0', 'dsadasdasd', '0', '0');
INSERT INTO `jdi_production` VALUES ('8', '44', '测试雪糕包装袋', '文波公司', '测试雪糕包装袋这个是', '71', '1425709286', '1425709286', '1', '2', '没有', '0', '0');
INSERT INTO `jdi_production` VALUES ('9', '44', '测试雪糕2', '文波公司', '阿迪达洒洒的', '73', '1425709682', '1425709682', '1', '0', '无', '0', '0');
INSERT INTO `jdi_production` VALUES ('10', '44', '测试雪糕3', '文波公司', '阿斯达', '74', '1425709704', '1425709704', '1', '0', '无', '0', '0');
INSERT INTO `jdi_production` VALUES ('11', '44', '测试雪糕4', '文波公司', '阿斯达是啊', '75', '1425710035', '1425710035', '-1', '0', '无', '0', '0');
INSERT INTO `jdi_production` VALUES ('12', '44', '测试雪糕4', '文波公司', '是否能解释的', '80', '1425714095', '1425714095', '1', '0', '呜呜呜', '0', '0');
INSERT INTO `jdi_production` VALUES ('13', '44', '测试雪糕5', '文波公司', '阿斯达水平', '80', '1425714113', '1425714113', '1', '0', '无', '0', '0');
INSERT INTO `jdi_production` VALUES ('14', '44', '测试雪糕6', '文波公司', '请问你', '81', '1425714132', '1425714132', '1', '0', '啊是', '0', '0');
INSERT INTO `jdi_production` VALUES ('15', '44', '测试雪糕7', '文波公司', '阿斯达啊', '74', '1425714205', '1425714205', '1', '0', '啊是', '0', '0');
INSERT INTO `jdi_production` VALUES ('16', '44', '测试雪糕8', '文波公司', '阿斯达', '82', '1425714330', '1425714330', '1', '0', '是', '0', '0');
INSERT INTO `jdi_production` VALUES ('17', '44', '测试雪糕9', '文波公司', '阿斯达', '82', '1425714345', '1425714345', '1', '0', '', '0', '0');
INSERT INTO `jdi_production` VALUES ('18', '44', '测试雪糕10', '文波公司', '做什么考试', '73', '1425714368', '1425714368', '1', '0', '阿斯达', '0', '0');
INSERT INTO `jdi_production` VALUES ('19', '44', '测试雪糕11', '文波公司', '阿斯兰卡', '83', '1425714391', '1425714391', '1', '0', '阿斯达', '0', '0');

-- -----------------------------
-- Table structure for `jdi_tieba`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_tieba`;
CREATE TABLE `jdi_tieba` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) NOT NULL COMMENT '名称',
  `content` text NOT NULL COMMENT '内容',
  `create_time` int(10) unsigned NOT NULL COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL COMMENT '更新时间',
  `status` tinyint(1) DEFAULT '1' COMMENT '状态',
  `uid` int(10) unsigned NOT NULL COMMENT '发布者',
  `is_top` tinyint(1) DEFAULT '0' COMMENT '是否置顶',
  `recommend` tinyint(1) DEFAULT '0' COMMENT '是否推荐',
  `excellent` tinyint(1) DEFAULT '0' COMMENT '是否设精',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `jdi_tieba`
-- -----------------------------
INSERT INTO `jdi_tieba` VALUES ('2', '123123132123123', '123123123123123123123123123123', '123123', '1425458020', '1', '0', '0', '0', '1');
INSERT INTO `jdi_tieba` VALUES ('3', '123', '', '1425457242', '1425457242', '-1', '0', '0', '0', '0');
INSERT INTO `jdi_tieba` VALUES ('4', '123', '', '1425457413', '1425457413', '-1', '0', '0', '0', '0');
INSERT INTO `jdi_tieba` VALUES ('5', '123', '', '1425457450', '1425457450', '-1', '0', '0', '0', '0');
INSERT INTO `jdi_tieba` VALUES ('6', '123', '', '1425457480', '1425457480', '-1', '0', '0', '0', '0');

-- -----------------------------
-- Table structure for `jdi_user_staff`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_user_staff`;
CREATE TABLE `jdi_user_staff` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `topic_table` char(30) NOT NULL,
  `topic_id` int(11) unsigned NOT NULL,
  `uid` int(11) unsigned NOT NULL,
  `create_time` int(11) unsigned DEFAULT NULL,
  `update_time` int(11) unsigned DEFAULT NULL,
  `action` char(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `jdi_user_staff`
-- -----------------------------
INSERT INTO `jdi_user_staff` VALUES ('5', 'member', '2', '1', '1425628603', '1425628603', '');
INSERT INTO `jdi_user_staff` VALUES ('6', 'member', '1', '1', '1425628664', '1425628664', '');
INSERT INTO `jdi_user_staff` VALUES ('7', 'company', '4', '1', '1425633955', '1425633955', 'like');
INSERT INTO `jdi_user_staff` VALUES ('8', 'tieba', '4', '1', '1425634281', '1425634281', 'like');
INSERT INTO `jdi_user_staff` VALUES ('9', 'company', '3', '1', '1425695607', '1425695607', '');
INSERT INTO `jdi_user_staff` VALUES ('10', 'company', '3', '1', '1425695678', '1425695678', 'collect');

-- -----------------------------
-- Table structure for `jdi_verify`
-- -----------------------------
DROP TABLE IF EXISTS `jdi_verify`;
CREATE TABLE `jdi_verify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `topic_table` char(40) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `result` tinyint(1) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

